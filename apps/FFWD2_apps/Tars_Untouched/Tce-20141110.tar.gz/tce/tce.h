/* Simple header for ISOC99 output from tce.py
 * Copyright (C) 2013 ET International, Inc.
 * written by Mark Glines
 */
#ifndef _TCE_H
#define _TCE_H

#include <errno.h>
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <complex.h>
#include <sys/types.h>
#include <assert.h>
#include <math.h>
#include <pthread.h>


#ifdef ECLIPSE
#define MODEL cc2
#define __OCR__
//#define __SWARM__
#ifndef NULL_GUID
#define NULL_GUID ((ocrGuid_t)0)
#endif /* NULL_GUID */
#ifndef EDT_PROP_NONE
#define EDT_PROP_NONE 0
#endif /* EDT_PROP_NONE */
#ifndef DB_PROP_NONE
#define DB_PROP_NONE 0
#endif /* DB_PROP_NONE */
#ifndef EDT_PARAM_UNK
#define EDT_PARAM_UNK -1
#endif /* EDT_PARAM_UNK */
#ifndef CblasNoTrans
#define CblasNoTrans 'N'
#endif /* CblasNoTrans */
#ifndef CblasTrans
#define CblasTrans 'T'
#endif /* CblasTrans */
#endif /* ECLIPSE */

#ifdef __OCR__
#include <ocr.h>
#else /* !__OCR__ */
#ifndef __SWARM__
#include <stdbool.h>
#endif /* !__SWARM__ */
#endif /* __OCR__ */

#ifdef __SWARM__
#include <eti/swarm_convenience.h>
#include <eti/tracing.h>
#endif /* __SWARM__ */

/* constants */
#define irrep_e 0
#define irrep_e2 0
#define irrep_f 0
#define irrep_v 0
#define irrep_t 0
#define irrep_t1 0
#define irrep_t2 0
#define irrep_t3 0

/* global GA allocation index things */
extern int *k_spin;
extern int *k_sym;
extern int *k_range;
extern int noab;
extern int nvab;
extern bool restricted, intorb;
extern double FACTORIAL[20];

/* If restricted == true, impose bounds checking on 2d array indices */
extern void tce_restricted_2(/*  inputs */ int  a1b, int  a2b,
                             /* outputs */ int *b1b, int *b2b);
/* If restricted == true, impose bounds checking on 4d array indices */
extern void tce_restricted_4(/*  inputs */ int  a1b, int  a2b, int  a3b, int  a4b,
                             /* outputs */ int *b1b, int *b2b, int *b3b, int *b4b);
extern void tce_sort_2(double *unsorted, double *sorted, int a, int b, int i, int j, double factor);
extern void tce_sort_4(double *unsorted, double *sorted, int a, int b, int c, int d, int i, int j, int k, int l, double factor);
int tce_hash(int *hash, int key);
extern void tce_get_hash_block(double *in, double *out, int dim, int *hash, int key);
extern void tce_add_hash_block(double *out, double *in, int dim, int *hash, int key);
void tce_get_block_ind_i(double *in, double *out, int dim, int w2b, int w1b, int w4b, int w3b);

/* Do a matrix multiply. */
#ifdef USE_MKL_BLAS
#include <mkl_cblas.h>
/* void cblas_dgemm(const  CBLAS_ORDER Order, const  CBLAS_TRANSPOSE TransA,
                    const  CBLAS_TRANSPOSE TransB, const MKL_INT M, const MKL_INT N,
                    const MKL_INT K, const double alpha, const double *A,
                    const MKL_INT lda, const double *B, const MKL_INT ldb,
                    const double beta, double *C, const MKL_INT ldc); */

#define TCE_DGEMM(tA, tB, M, N, K, alpha, A, LDA, B, LDB, beta, C, LDC) cblas_dgemm(CblasColMajor, tA, tB, M, N, K, alpha, A, LDA, B, LDB, beta, C, LDC)
#elif USE_ATLAS_BLAS
#include <atlas/cblas.h>
/* void cblas_dgemm(const enum CBLAS_ORDER Order, const enum CBLAS_TRANSPOSE TransA,
                    const enum CBLAS_TRANSPOSE TransB, const int M, const int N,
                    const int K, const double alpha, const double *A,
                    const int lda, const double *B, const int ldb,
                    const double beta, double *C, const int ldc); */
#define TCE_DGEMM(tA, tB, M, N, K, alpha, A, LDA, B, LDB, beta, C, LDC) cblas_dgemm(CblasColMajor, tA, tB, M, N, K, alpha, A, LDA, B, LDB, beta, C, LDC)
#else
#warning no BLAS library specified
extern void TCE_DGEMM(char transposeA, char transposeB, int m, int n, int k, double alpha,
        double *A, int lda, double *B, int ldb, double beta, double *C, int ldc);
#endif

#define debug(a, b...) do { printf("%s:%d: " a "\n", __FILE__, __LINE__, ##b); fflush(stdout); } while(0)
#define die(a, b...) do { fprintf(stderr,"FATAL: %s:%d: " a "\n", __FILE__, __LINE__, ##b); fflush(stderr); abort(); } while(0)
#define die_if(a) if((a)) die("failed assert: " #a)

static inline void *_tce_malloc(size_t size) {
    void *rv = calloc(size, 1);
    if(!rv)
        die("calloc of size %zd failed with errno %d (%s)", size, errno, strerror(errno));
    return rv;
}

static inline int *tce_int_malloc(size_t count) {
    int *rv = (int*)_tce_malloc(count * sizeof(int));
    return rv;
}

static inline double *tce_double_malloc(size_t count) {
    double *rv = (double*)_tce_malloc(count * sizeof(double));
    return rv;
}

static inline void tce_free(void *ptr) {
    free(ptr);
}

void write_tensor(char *filename, double *data, size_t len);
#ifdef __OCR__
ocrGuid_t generic_double_sum(u32 paramc, u64* paramv, u32 depc, ocrEdtDep_t depv[]);
ocrGuid_t generic_double_mm_mult(u32 paramc, u64* paramv, u32 depc, ocrEdtDep_t depv[]);
/* Tensor representation:
 * * Header struct (tensor_t)
 * * Lookup table
 * * GUID table
 */
#define MAX_N 8
typedef struct {
    ocrGuid_t guid;
    int size[MAX_N]; /* Size of block */
    int pos[MAX_N];  /* Position of block within tensor (in block-rows, block-cols, etc) */
    double data[0];
} tensor_block_desc_t;
#define BLOCK_SIZE(doubles) (sizeof(tensor_block_desc_t)+(doubles)*sizeof(double))
typedef struct {
    int num_iters;  /* How many indices the tensor has (usually a multiple of 2; 2 is a matrix-like tensor) */
    int num_blocks; /* How many blocks are present */
    int minpos[MAX_N];
    int maxpos[MAX_N];
    tensor_block_desc_t blocks[0];
} tensor_t;
tensor_block_desc_t *find_block(tensor_t *tensor, int *i);
#define TENSOR_SIZE(blocks) (sizeof(tensor_t)+(blocks)*BLOCK_SIZE(0))
enum {
    TEMPLATE_BLOCK_SUM = 0,
    TEMPLATE_TENSOR_SUM,
    TEMPLATE_INTORB,
    TEMPLATE_SORT_2D,
    TEMPLATE_SORT_4D,
    TEMPLATE_MM,
    TEMPLATE_REBADGE,
    _TEMPLATE_COUNT /* last member */
};
void dump_tensor_by_guid(ocrGuid_t guid);
void dump_block_by_guid(ocrGuid_t guid, int num_iters);
#else /* !__OCR__ */
void dump_tensor(double *data, int *hash, int dims, int *sizes, int *starts);
void dump_block(double *data, int len);
#endif /* __OCR__ */
#ifdef __SWARM__
typedef struct {
    const swarm_Codelet_t *NEXT;
    void *NEXT_THIS;
} generic_continuation_t;
typedef struct {
    void *buffer;
    struct argument_list *head;
    generic_continuation_t free; /* to free this argument buffer */
} argument_chunk_t;
typedef struct argument_list {
    int len, count;
    swarm_Dep_t dep;
    generic_continuation_t done; /* to return the complete data */
    argument_chunk_t args[0];
} argument_list_t;
#define ARGUMENT_LIST_SIZE(inputs) (sizeof(argument_list_t)+(inputs)*sizeof(argument_chunk_t))
CODELET_IMPORT(sum);
CODELET_IMPORT(satisfy);
CODELET_IMPORT(free_arg_list);
CODELET_IMPORT(free);
#define ARGUMENT_INIT(_count,_codelet,_this,_input,_next,_next_this,_a...) (argument_list_t){ .dep = swarm_Dep_INITIALIZER(_count,_codelet,_this,_input), .done = { .NEXT = _next, .NEXT_THIS = _next_this }, .count = _count, ##_a }
#endif /* __OCR__ */

#define min(a,b) ((a) < (b) ? (a) : (b))
#define max(a,b) ((a) > (b) ? (a) : (b))

#endif /* _TCE_H */
