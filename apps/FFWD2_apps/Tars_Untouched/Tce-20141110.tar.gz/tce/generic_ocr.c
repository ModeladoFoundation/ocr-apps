/* Copyright (C) 2013 ET International, Inc. */

#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <math.h>
#include "tce.h"

//#define DEBUG_ALLOC
#ifdef DEBUG_ALLOC
#define debug_alloc(a...) debug(a)
#else
#define debug_alloc(a...)
#endif

#define CHECK_R1
#define CHECK_R2

#define EPSILON 1e-15

static ocrGuid_t tce_block_sum(u32 paramc, u64* paramv, u32 depc, ocrEdtDep_t depv[]);
static ocrGuid_t tce_tensor_sum(u32 paramc, u64* paramv, u32 depc, ocrEdtDep_t depv[]);
static ocrGuid_t tce_block_rebadge(u32 paramc, u64* paramv, u32 depc, ocrEdtDep_t depv[]);
static ocrGuid_t tce_block_sort_2d(u32 paramc, u64* paramv, u32 depc, ocrEdtDep_t depv[]);
static ocrGuid_t tce_block_sort_4d(u32 paramc, u64* paramv, u32 depc, ocrEdtDep_t depv[]);
static ocrGuid_t tce_block_intorb(u32 paramc, u64* paramv, u32 depc, ocrEdtDep_t depv[]);
static ocrGuid_t tce_block_mm(u32 paramc, u64* paramv, u32 depc, ocrEdtDep_t depv[]);
static ocrGuid_t convert_tensor_to_block_form(int blocks, int iters, int *sizes, int *hash_begin, int *block_begin, double *data, int *offsets);
static ocrGuid_t convert_intorb_tensor_to_block_form(int *sizes, int *hash_begin, int *block_begin, double *data);

/* The extra nesting is to convince cpp to generate a function name like cc2_t1,
 * rather than MODEL_t1 or errors like "stray ‘##’ in program" and
 * "unknown type name ‘cc2’" */
#define _FUNC2(model,suffix) model ## _ ## suffix
#define _FUNC1(model,suffix) _FUNC2(model,suffix)
#define  FUNC(suffix) _FUNC1(MODEL,suffix)

/* Similarly, the extra nesting convinces cpp to generate a string like "cc2",
 * rather than "macro" or "MODEL" */
#define _STRINGIFY1(macro) #macro
#define STRINGIFY(macro) _STRINGIFY1(macro)

ocrGuid_t FUNC(t1) (u32 paramc, u64* paramv, u32 depc, ocrEdtDep_t depv[]);
ocrGuid_t FUNC(t2) (u32 paramc, u64* paramv, u32 depc, ocrEdtDep_t depv[]);

#define ENTRIES(a) (sizeof(a)/sizeof(a[0]))
static char *scalar_names[] = (char*[]) {
    "noa",
    "nob",
    "nva",
    "nvb",
    "noab",
    "nvab",
    "io_v2",
    "intorb",
    "size_f1",
    "size_t1",
    "size_t2",
    "size_v2",
    "restricted",
};
enum {
    si_noa = 0,
    si_nob,
    si_nva,
    si_nvb,
    si_noab,
    si_nvab,
    si_io_v2,
    si_intorb,
    si_size_f1,
    si_size_t1,
    si_size_t2,
    si_size_v2,
    si_restricted,
    NUM_SCALARS
};
static char *vector_names[] = (char*[]) {
    "k_sym",
    "k_b2am",
    "k_spin",
    "k_alpha",
    "k_range",
    "k_offset",
    "k_f1_offset",
    "k_t1_offset",
    "k_t2_offset",
    "k_v2_offset",
    "k_sym_alpha",
    "k_spin_alpha",
    "k_range_alpha",
    "k_v2_alpha_offset",
};
enum {
    vi_sym = 0,
    vi_b2am,
    vi_spin,
    vi_alpha,
    vi_range,
    vi_offset,
    vi_f1_offset,
    vi_t1_offset,
    vi_t2_offset,
    vi_v2_offset,
    vi_sym_alpha,
    vi_spin_alpha,
    vi_range_alpha,
    vi_v2_alpha_offset,
    NUM_VECTORS
};
static char *tensor_names[] = (char*[]) {
    "f1",
    "v2",
    "t1",
    "t2",
    "r1",
    "r2",
};
enum {/* Note: this determines the order of command line arguments. */
    ti_f1 = 0,
    ti_v2,
    ti_t1,
    ti_t2,
    ti_r1,
    ti_r2,
    NUM_TENSORS
};

int *k_sym;
int *k_b2am;
int *k_spin;
int *k_alpha;
int *k_range;
int *k_offset;
int *k_sym_alpha;
int *k_spin_alpha;
int *k_range_alpha;
int *k_v2_alpha_offset;
int noab, nvab, noa, nob, nva, nvb, io_v2;
bool restricted, intorb;

double FACTORIAL[20];
int *scalars, *vector_sizes, **vectors, *tensor_sizes;
double **tensors;

void tce_hash_v2_prepare(const int *hash, int M);

ocrGuid_t followup(u32 paramc, u64 *paramv, u32 depc, ocrEdtDep_t *depv);
ocrGuid_t mainEdt(u32 paramc, u64 *paramv, u32 depc, ocrEdtDep_t *depv) {
    FILE *f;
    int i, j;
    char line[256];
#if defined(CHECK_R1) || defined(CHECK_R2)
    ocrGuid_t
#ifdef CHECK_R1
              FUNC(t1_template), FUNC(t1_edt), FUNC(t1_done),
#endif
#ifdef CHECK_R2
              FUNC(t2_template), FUNC(t2_edt), FUNC(t2_done),
#endif
              affinity = 0;
#endif
    ocrGuid_t followup_template, followup_edt;
    u64  *depv0_as_u64  = (u64 *)depv[0].ptr;
    char *depv0_as_char = (char*)depv[0].ptr;
    int argc = depv0_as_u64[0];
    char *argv[argc];
    for(i = 0; i < argc; i++)
        argv[i] = depv0_as_char + depv0_as_u64[i+1];
    scalars      = calloc(NUM_SCALARS, sizeof(int));
    vector_sizes = calloc(NUM_VECTORS, sizeof(int));
    vectors      = calloc(NUM_VECTORS, sizeof(int*));
    tensor_sizes = calloc(NUM_TENSORS, sizeof(int));
    tensors      = calloc(NUM_TENSORS, sizeof(double*));
    if(!scalars || !vector_sizes || !vectors || !tensor_sizes)
        die("malloc failure");
    if(argc < 8)
        die("argc is %d.  Usage: %s <params> <f1> <v2> <t1> <t2> <r1> <r2>", argc, argv[0]);
    f = fopen(argv[1], "r");
    if(!f)
        die("Cannot open params file %s", argv[1]);
    if(!fgets(line, sizeof(line), f))
        die("Could not read line of params file");
    /* parse scalar constants */
    uint64_t mask = 0;
    while(!strchr(line, '[')) {
        /* line[] contains something like "size_v2=   7970724", parse it. */
        for(i = 0; i < NUM_SCALARS; i++) {
            if(!strncmp(line, scalar_names[i], strlen(scalar_names[i])) && (
                    line[strlen(scalar_names[i])] == ' '
                 || line[strlen(scalar_names[i])] == '='))
                break;
        }
        if(i == NUM_SCALARS)
            die("Could not find scalar variable name in line \"%s\"", line);
        mask |= (1ULL<<i);
        char *equals = strchr(line,'=');
        if(!equals)
            die("Could not find equal sign in line \"%s\"", line);
        scalars[i] = strtol(equals+1,NULL,0);

        if(!fgets(line, sizeof(line), f))
            die("Could not read line of params file");
    }
    for(i = 0; i < NUM_SCALARS; i++) {
        if(!(mask & (1ULL<<i)))
            printf("scalar \"%s\" not found in params file, defaulting to 0.\n", scalar_names[i]);
    }
    /* parse vector constants */
    mask = 0;
    while(1) {
        /* line[] contains something like "k_sym[18]=", parse it. */
        for(i = 0; i < NUM_VECTORS; i++) {
            if(!strncmp(line, vector_names[i], strlen(vector_names[i]))
            && line[strlen(vector_names[i])] == '[')
                break;
        }
        if(i == NUM_VECTORS)
            die("Could not find vector variable name in line \"%s\"", line);
        mask |= (1ULL<<i);
        char *bracket = strchr(line,'[');
        if(!bracket)
            die("Could not find square brackets in line \"%s\"", line);
        vector_sizes[i] = strtol(bracket+1,NULL,0);
        vectors[i] = malloc(sizeof(vectors[i][0])*vector_sizes[i]);
        if(!vectors[i])
            die("Could not malloc buffer of size %zd for vector %s (%d)",
                sizeof(vectors[i][0])*vector_sizes[i], vector_names[i], i);
        for(j = 0; j < vector_sizes[i]; j++) {
            if(!fgets(line, sizeof(line), f))
                die("Could not read element %d of vector %s (%d)",
                    j, vector_names[i], i);
            /* line[] contains something like "     1     0", parse it. */
            char *ptr;
            int index, value;
            index = strtol(line, &ptr, 0);
            value = strtol(ptr , NULL, 0);
            if(j != index-1)
                die("index mismatch in %s: %d != %d", vector_names[i],j+1,index);

            vectors[i][j] = value;
        }

        if(!fgets(line, sizeof(line), f)) {
            fclose(f);
            break;
        }
    }
    for(i = 0; i < NUM_VECTORS; i++) {
        if(!(mask & (1ULL<<i)))
            printf("vector \"%s\" not found in params file, defaulting to NULL.\n", vector_names[i]);
    }
    /* read tensors */
    tensor_sizes[0] = scalars[si_size_f1]; /* size_f1 */
    tensor_sizes[1] = scalars[si_size_v2]; /* size_v2 */
    tensor_sizes[2] = scalars[si_size_t1]; /* size_t1 */
    tensor_sizes[3] = scalars[si_size_t2]; /* size_t2 */
    tensor_sizes[4] = scalars[si_size_t1]; /* r1 has the same size as t1 */
    tensor_sizes[5] = scalars[si_size_t2]; /* r2 has the same size as t2 */
    for(i = 0; i < 6; i++) {
        f = fopen(argv[2+i], "r");
        if(!f)
            die("Cannot open %s file %s", tensor_names[i], argv[2+i]);
        tensors[i] = malloc(sizeof(tensors[i][0]) * tensor_sizes[i]);
        if(!tensors[i])
            die("Could not malloc buffer of size %zd for tensor %s (%d)",
                sizeof(tensors[i][0])*tensor_sizes[i], tensor_names[i], i);
        int rv = fread(tensors[i], sizeof(tensors[i][0]), tensor_sizes[i], f);
        if(rv != tensor_sizes[i])
            die("reading tensor %s (%d), fread() returned %d, wanted %d",
                    tensor_names[i], i, rv, tensor_sizes[i]);
        fclose(f);
    }

    /* Set up global scalars */
    noa        = scalars[si_noa];
    nob        = scalars[si_nob];
    nva        = scalars[si_nva];
    nvb        = scalars[si_nvb];
    noab       = scalars[si_noab];
    nvab       = scalars[si_nvab];
    io_v2      = scalars[si_io_v2];
    intorb     = scalars[si_intorb];
    restricted = scalars[si_restricted];
    /* Set up global vectors */
    k_sym             = vectors[vi_sym];
    k_b2am            = vectors[vi_b2am];
    k_spin            = vectors[vi_spin];
    k_alpha           = vectors[vi_alpha];
    k_range           = vectors[vi_range];
    k_offset          = vectors[vi_offset];
    k_sym_alpha       = vectors[vi_sym_alpha];
    k_spin_alpha      = vectors[vi_spin_alpha];
    k_range_alpha     = vectors[vi_range_alpha];
    k_v2_alpha_offset = vectors[vi_v2_alpha_offset];
    FACTORIAL[0] = 1;
    for(i = 1; i < ENTRIES(FACTORIAL); i++)
        FACTORIAL[i] = FACTORIAL[i-1] * i;

#if defined(CHECK_R1) || defined(CHECK_R2)
    ocrGuid_t templates_guid, *templates;
    debug_alloc("alloc %zd", sizeof(ocrGuid_t)*_TEMPLATE_COUNT);
    die_if(ocrDbCreate(&templates_guid, (void**)&templates, sizeof(ocrGuid_t)*_TEMPLATE_COUNT, DB_PROP_NONE, NULL_GUID, NO_ALLOC));
    memset(templates,0,sizeof(ocrGuid_t)*_TEMPLATE_COUNT);
    ocrEdtTemplateCreate(&templates[TEMPLATE_BLOCK_SUM] , tce_block_sum    , 1            , EDT_PARAM_UNK);
    ocrEdtTemplateCreate(&templates[TEMPLATE_TENSOR_SUM], tce_tensor_sum   , 1            , EDT_PARAM_UNK);
    ocrEdtTemplateCreate(&templates[TEMPLATE_INTORB]    , tce_block_intorb , 4            , 2);
    ocrEdtTemplateCreate(&templates[TEMPLATE_SORT_2D]   , tce_block_sort_2d, 3            , 1);
    ocrEdtTemplateCreate(&templates[TEMPLATE_SORT_4D]   , tce_block_sort_4d, EDT_PARAM_UNK, 1);
    ocrEdtTemplateCreate(&templates[TEMPLATE_MM]        , tce_block_mm     , EDT_PARAM_UNK, 2);
    ocrEdtTemplateCreate(&templates[TEMPLATE_REBADGE]   , tce_block_rebadge, EDT_PARAM_UNK, 1);

    ocrEdtTemplateCreate(&followup_template, followup, 0, 4);
    ocrEdtCreate(&followup_edt, followup_template, 0, NULL, 4, NULL, EDT_PROP_NONE, affinity, NULL);
    ocrGuid_t f1_blocked_guid
        = convert_tensor_to_block_form(vectors[vi_f1_offset][0], 2,
                                       (int[]){noab+nvab,noab+nvab},
                                       (int[]){0        ,0        },
                                       (int[]){0        ,0        },
                                       tensors[ti_f1], vectors[vi_f1_offset]);
    ocrGuid_t t1_blocked_guid
        = convert_tensor_to_block_form(vectors[vi_t1_offset][0], 2,
                                       (int[]){nvab,noab},
                                       (int[]){noab,0   },
                                       (int[]){0   ,0   },
                                       tensors[ti_t1], vectors[vi_t1_offset]);
    ocrGuid_t t2_blocked_guid
        = convert_tensor_to_block_form(vectors[vi_t2_offset][0], 4,
                                       (int[]){nvab,nvab,noab,noab},
                                       (int[]){noab,noab,0   ,0   },
                                       (int[]){0   ,0   ,0   ,0   },
                                       tensors[ti_t2], vectors[vi_t2_offset]);
    ocrGuid_t v2_blocked_guid;
    if(!intorb)
        v2_blocked_guid = convert_tensor_to_block_form(vectors[vi_v2_offset][0], 4,
                                       (int[]){noab+nvab,noab+nvab,noab+nvab,noab+nvab},
                                       (int[]){0        ,0        ,0        ,0        },
                                       (int[]){0        ,0        ,0        ,0        },
                                       tensors[ti_v2], vectors[vi_v2_offset]);
    else
        v2_blocked_guid = convert_intorb_tensor_to_block_form(
                                       (int[]){noa+nva,noa+nva,noa+nva,noa+nva},
                                       (int[]){0      ,0      ,0      ,0      },
                                       (int[]){0      ,0      ,0      ,0      },
                                       tensors[ti_v2]);
#endif /* CHECK_R1 || CHECK_R2 */
#ifdef CHECK_R1
    ocrGuid_t r1_blocked_guid
        = convert_tensor_to_block_form(vectors[vi_t1_offset][0], 2,
                                       (int[]){nvab,noab},
                                       (int[]){noab,0   },
                                       (int[]){noab,0   },
                                       tensors[ti_r1], vectors[vi_t1_offset]);
    /* Call cc2_t1 or ccsd_t1 or whatever */
    printf("Calling " STRINGIFY(MODEL) "_t1 (size=%d)\n", scalars[si_size_t1]);
    ocrEdtTemplateCreate(&FUNC(t1_template), FUNC(t1), 1, 5);
    ocrEdtCreate(&FUNC(t1_edt), FUNC(t1_template), 1, &(u64){vectors[vi_t1_offset][0]},
                 5, (ocrGuid_t[]){f1_blocked_guid,t1_blocked_guid,t2_blocked_guid,v2_blocked_guid,templates_guid},
            EDT_PROP_NONE, affinity, &FUNC(t1_done));
    ocrAddDependence(r1_blocked_guid, followup_edt, 0, DB_MODE_RO);
    ocrAddDependence(FUNC(t1_done)  , followup_edt, 1, DB_MODE_RO);
#else
    ocrAddDependence(NULL_GUID, followup_edt, 0, DB_MODE_RO);
    ocrAddDependence(NULL_GUID, followup_edt, 1, DB_MODE_RO);
#endif

#ifdef CHECK_R2
    ocrGuid_t r2_blocked_guid
        = convert_tensor_to_block_form(vectors[vi_t2_offset][0], 4,
                                       (int[]){nvab,nvab,noab,noab},
                                       (int[]){noab,noab,0   ,0   },
                                       (int[]){noab,noab,0   ,0   },
                                       tensors[ti_r2], vectors[vi_t2_offset]);
    /* Call cc2_t2 or ccsd_t2 or whatever */
    printf("Calling " STRINGIFY(MODEL) "_t2 (size=%d)\n", scalars[si_size_t2]);
    ocrEdtTemplateCreate(&FUNC(t2_template), FUNC(t2), 1, 5);
    ocrEdtCreate(&FUNC(t2_edt), FUNC(t2_template), 1, &(u64){vectors[vi_t2_offset][0]},
                 5, (ocrGuid_t[]){f1_blocked_guid,t1_blocked_guid,t2_blocked_guid,v2_blocked_guid,templates_guid},
            EDT_PROP_NONE, affinity, &FUNC(t2_done));
    ocrAddDependence(r2_blocked_guid, followup_edt, 2, DB_MODE_RO);
    ocrAddDependence(FUNC(t2_done)  , followup_edt, 3, DB_MODE_RO);
#else
    ocrAddDependence(NULL_GUID, followup_edt, 2, DB_MODE_RO);
    ocrAddDependence(NULL_GUID, followup_edt, 3, DB_MODE_RO);
#endif /* CHECK_R2 */
    return NULL_GUID;
}

/* Straight translations of src/tce/tce_restricted.F, minus the int_mb nonsense */
void tce_restricted_2(int a1b, int a2b, int *b1b, int *b2b) {
    if(restricted && k_spin[a1b]+k_spin[a2b] == 4) {
        *b1b = k_alpha[a1b] - 1;
        *b2b = k_alpha[a2b] - 1;
    } else {
        *b1b = a1b;
        *b2b = a2b;
    }
}
void tce_restricted_4(int a1b, int a2b, int a3b, int a4b, int *b1b, int *b2b, int *b3b, int *b4b) {
    if(restricted && k_spin[a1b]+k_spin[a2b]+k_spin[a3b]+k_spin[a4b] == 8) {
        *b1b = k_alpha[a1b] - 1;
        *b2b = k_alpha[a2b] - 1;
        *b3b = k_alpha[a3b] - 1;
        *b4b = k_alpha[a4b] - 1;
    } else {
        *b1b = a1b;
        *b2b = a2b;
        *b3b = a3b;
        *b4b = a4b;
    }
}


/* Rearrange the 2d input array, multiplying values by the amplitude factor.
 * [a,b] defines the length, along each dimension, of the input arrays.
 * [i,j] defines the target index order.  [0,1] is a direct copy; [1,0] transposes. */
void tce_sort_2(double *in, double *out, int a, int b, int i, int j, double factor) {
    /* more-or-less direct translation of tce_sort2.F */
    int pos[2],len[2],ia,ib,j1,j2;
    ia = 0;
    if(i == 0 && j == 1) {
        /* no permutation, just copy and apply the scale factor */
        for(ia = 0; ia < a * b; ia++)
            out[ia] = in[ia] * factor;
        return;
    }
    len[0] = a;
    len[1] = b;
    for(j1 = 0; j1 < a; j1++) {
        pos[0] = j1;
        for(j2 = 0; j2 < b; j2++) {
            pos[1] = j2;
            ib = pos[j]+len[j]*pos[i];
            out[ib] = in[ia++] * factor;
        }
    }
}

/* Rearrange the 4d input array, multiplying values by the amplitude factor.
 * [a,b,c,d] defines the length, along each dimension, of the input arrays.
 * [i,j,k,l] defines the target index order.  [0,1,2,3] is a direct copy. */
void tce_sort_4(double *in, double *out, int a, int b, int c, int d, int i, int j, int k, int l, double factor) {
    /* a simple extrapolation of TCE_SORT_2.  The original TCE has two
     * tce_sort_4*.F sources, it's not clear which one is used, and they are
     * both much more heavily optimized than this. */
    int pos[4],len[4],ia,ib,j1,j2,j3,j4;
    ia = 0;
    len[0] = a;
    len[1] = b;
    len[2] = c;
    len[3] = d;
    for(j1 = 0; j1 < a; j1++) {
        pos[0] = j1;
        for(j2 = 0; j2 < b; j2++) {
            pos[1] = j2;
            for(j3 = 0; j3 < c; j3++) {
                pos[2] = j3;
                for(j4 = 0; j4 < d; j4++) {
                    pos[3] = j4;
                    ib = len[j]*len[k]*len[l]*pos[i]
                       +        len[k]*len[l]*pos[j]
                       +               len[l]*pos[k]
                       +                      pos[l];
                    out[ib] = in[ia++] * factor;
                }
            }
        }
    }
}

void write_tensor(char *filename, double *data, size_t len) {
    size_t record_size = 2*1024*1024/8;
    double d;
    FILE *f = fopen(filename, "w");
    fwrite(data, sizeof(*data), len, f);
    while(len % record_size) {
        d = 0;
        fwrite(&d, sizeof(d), 1, f);
        len++;
    }
    fclose(f);
}

ocrGuid_t generic_double_sum(u32 paramc, u64* paramv, u32 depc, ocrEdtDep_t depv[]) {
    assert(paramc >= 1);
    assert(depc >= 1);
    int i, j, len = paramv[0];
    double *out;
    ocrGuid_t rv;
    debug_alloc("alloc %zd", len*sizeof(double));
    die_if(ocrDbCreate(&rv, (void**)&out, (len)*sizeof(double), DB_PROP_NONE, NULL_GUID, NO_ALLOC));
    memset(out, 0, sizeof(*out)*len);
    for(i = 0; i < depc; i++) {
        double *in = (double*)depv[i].ptr;
        for(j = 0; j < len; j++) {
            out[j] += in[j];
        }
    }
    return rv;
}

int block_comparator(const void *a_, const void *b_) {
    tensor_block_desc_t *a = (tensor_block_desc_t*)a_, *b = (tensor_block_desc_t*)b_;
    int i;
    for(i = 0; i < MAX_N; i++) {
        if(a->pos[i] != b->pos[i])
            return a->pos[i] - b->pos[i];
    }
    return 0;
}

tensor_block_desc_t *find_block(tensor_t *tensor, int *indices) {
    /* Yet another binary search. */
#if 1
    int i;
    for(i = 1; i < tensor->num_blocks; i++)
        if(block_comparator(&tensor->blocks[0], &tensor->blocks[i]) >= 0)
            die("find_block: tensor %p is not in ascending order: tensor->blocks[%d] <= tensor->blocks[0] (%d,%d,%d,%d <= %d,%d,%d,%d)", tensor, i,
                tensor->blocks[i].pos[0], tensor->blocks[i].pos[1], tensor->blocks[i].pos[2], tensor->blocks[i].pos[3],
                tensor->blocks[0].pos[0], tensor->blocks[0].pos[1], tensor->blocks[0].pos[2], tensor->blocks[0].pos[3]);
#endif
    tensor_block_desc_t request;
    memset(&request, 0, sizeof(request));
    memcpy(request.pos, indices, tensor->num_iters*sizeof(request.pos[0]));
    tensor_block_desc_t *rv = bsearch(&request,tensor->blocks,tensor->num_blocks,sizeof(request),block_comparator);
    die_if(!rv);
    return rv;
}


ocrGuid_t tce_block_sum(u32 paramc, u64* paramv, u32 depc, ocrEdtDep_t depv[]) {
    assert(paramc == 1);
    assert(depc >= 1);
    int len = paramv[0];
    int i, j;
    tensor_block_desc_t *out;
    /* The identity blocks (in the intorb case) are derived from a tensor with
     * different addressing, and so the position is screwed up.  Those blocks
     * are always at the beginning of the list, so take the position and size
     * from the last block in the list, rather than the first one. */
    tensor_block_desc_t *lastin = (tensor_block_desc_t*)depv[depc-1].ptr;
    ocrGuid_t rv;
    double *pointers[depc];
//    debug("block sum across %d blocks", depc);
    if(depc == 1)
        return depv[0].guid;
    debug_alloc("alloc %zd", BLOCK_SIZE(len));
    die_if(ocrDbCreate(&rv, (void**)&out, BLOCK_SIZE(len), DB_PROP_NONE, NULL_GUID, NO_ALLOC));
    memset(out, 0, BLOCK_SIZE(len));
    memcpy(out->pos , lastin->pos , sizeof(out->pos ));
    memcpy(out->size, lastin->size, sizeof(out->size));
    out->guid = rv;
    for(i = 0; i < depc; i++) {
        tensor_block_desc_t *in = (tensor_block_desc_t*)depv[i].ptr;
        pointers[i] = in->data;
#if 0
        if(memcmp(in0->pos, in->pos, sizeof(in0->pos))) {
            die("position mismatch for block");
        }
        if(memcmp(in0->size, in->size, sizeof(in0->size))) {
            die("size mismatch for block");
        }
#endif
    }
    for(j = 0; j < len; j++) {
        out->data[j] = 0;
        for(i = 0; i < depc; i++) {
            out->data[j] += pointers[i][j];
        }
    }

    /* bit hacky, but whatever: this works because I know only intermediate buffers are passed to this EDT. */
//    for(i = 0; i < depc; i++)
//        ocrDbDestroy(depv[i].guid);

    return rv;
}


ocrGuid_t tce_tensor_sum(u32 paramc, u64* paramv, u32 depc, ocrEdtDep_t depv[]) {
    assert(paramc == 1);
    assert(depc >= 1);
    int i, j, tensor_len;
    ocrGuid_t block_sum_template = paramv[0];
    tensor_t  *in0_tensor = (tensor_t*)depv[0].ptr;
    tensor_t *out_tensor, *in_tensor;
    ocrGuid_t rv, block_sum_edt, block_sum_done;
    if(depc == 1)
        return depv[0].guid;
//    debug("tensor sum across %d tensors", depc);
    tensor_len = TENSOR_SIZE(in0_tensor->num_blocks);
    debug_alloc("alloc %d", tensor_len);
    die_if(ocrDbCreate(&rv, (void**)&out_tensor, tensor_len, DB_PROP_NONE, NULL_GUID, NO_ALLOC));
    memcpy(out_tensor, in0_tensor, tensor_len);
    for(i = 0; i < in0_tensor->num_blocks; i++) {
        tensor_block_desc_t *out_block = &out_tensor->blocks[i];
        tensor_block_desc_t * in_block = &in0_tensor->blocks[i];
        int block_len = 1;
        for(j = 0; j < in0_tensor->num_iters; j++)
            block_len *= in_block->size[j];
        ocrEdtCreate(&block_sum_edt, block_sum_template, 1, (u64[]){block_len}, depc, NULL, EDT_PROP_NONE, NULL_GUID, &block_sum_done);
        ocrEventCreate(&out_block->guid, OCR_EVENT_STICKY_T, 1);
        ocrAddDependence(block_sum_done, out_block->guid, 0, DB_MODE_RO);
        for(j = 0; j < depc; j++) {
            in_tensor = (tensor_t*)depv[j].ptr;
            in_block = &in_tensor->blocks[i];
#if 0
            if(memcmp(out_block->pos, in_block->pos, sizeof(out_block->pos))) {
                if(in0_tensor->num_iters == 2)
                    die("inner position mismatch for 2d block: out=[%d,%d] ref=[%d,%d]",
                        out_block->pos[0], out_block->pos[1], in_block->pos[0], in_block->pos[1]);
                if(in0_tensor->num_iters == 4)
                    die("inner position mismatch for 4d block: out=[%d,%d,%d,%d] ref=[%d,%d,%d,%d]",
                        out_block->pos[0], out_block->pos[1], out_block->pos[2], out_block->pos[3],
                         in_block->pos[0],  in_block->pos[1],  in_block->pos[2],  in_block->pos[3]);
                die("position mismatch for %dd block", in0_tensor->num_iters);
            }
            if(memcmp(out_block->size, in_block->size, sizeof(out_block->size))) {
                if(in0_tensor->num_iters == 2)
                    die("inner size mismatch for 2d block: out=[%d,%d] ref=[%d,%d]",
                        out_block->size[0], out_block->size[1], in_block->size[0], in_block->size[1]);
                if(in0_tensor->num_iters == 4)
                    die("inner size mismatch for 4d block: out=[%d,%d,%d,%d] ref=[%d,%d,%d,%d]",
                        out_block->size[0], out_block->size[1], out_block->size[2], out_block->size[3],
                         in_block->size[0],  in_block->size[1],  in_block->size[2],  in_block->size[3]);
                die("size mismatch for %dd block", in0_tensor->num_iters);
            }
#endif
            ocrAddDependence(in_block->guid, block_sum_edt, j, DB_MODE_RO);
        }
    }
    return rv;
}

#ifdef FULL_SSA
/* Create a new block with copied data and new header values. */
ocrGuid_t tce_block_rebadge(u32 paramc, u64* paramv, u32 depc, ocrEdtDep_t depv[]) {
    assert(depc == 1);
    assert(paramc > 1);
    assert((paramc & 1) == 0);
    int i, iters = paramc >> 1;
    tensor_block_desc_t *in = (tensor_block_desc_t*)depv[0].ptr;
    tensor_block_desc_t *out;
    int size = 1;
    ocrGuid_t db;
    if(in->size[iters-1] == 0 || in->size[iters] != 0)
        die("mismatch in number of iterators?");
    for(i = 0; i < iters; i++)
        size *= in->size[i];
    debug_alloc("alloc %zd", BLOCK_SIZE(size));
    die_if(ocrDbCreate(&db, (void**)&out, BLOCK_SIZE(size), DB_PROP_NONE, NULL_GUID, NO_ALLOC));
    memcpy(out, in, BLOCK_SIZE(size));
    for(i = 0; i < iters; i++) {
        out->pos [i] = paramv[i];
        out->size[i] = paramv[i + iters];
    }
    out->guid = db;
    if(iters == 2)
        debug("rebadging %ld (%p) %dx%d@%d,%d to %ld (%p) %dx%d@%d,%d",
                 in->guid,  in->data,  in->size[0],  in->size[1],  in->pos[0],  in->pos[1],
                out->guid, out->data, out->size[0], out->size[1], out->pos[0], out->pos[1]);
    else if(iters == 4)
        debug("rebadging %ld (%p) %dx%dx%dx%d@%d,%d,%d,%d to %ld %p %dx%dx%dx%d@%d,%d,%d,%d",
               in->guid,  in->data,  in->size[0],  in->size[1],  in->size[2],  in->size[3],  in->pos[0],  in->pos[1],  in->pos[2],  in->pos[3],
              out->guid, out->data, out->size[0], out->size[1], out->size[2], out->size[3], out->pos[0], out->pos[1], out->pos[2], out->pos[3]);
    return db;
}
#else /* !FULL_SSA */
/* Rewrite the block header in place. */
ocrGuid_t tce_block_rebadge(u32 paramc, u64* paramv, u32 depc, ocrEdtDep_t depv[]) {
    assert(depc == 1);
    assert(paramc > 1);
    assert((paramc & 1) == 0);
    int i, iters = paramc >> 1;
    tensor_block_desc_t *out = (tensor_block_desc_t*)depv[0].ptr;
    if(out->size[iters-1] == 0 || out->size[iters] != 0)
        die("mismatch in number of iterators?");
    for(i = 0; i < iters; i++) {
        out->pos [i] = paramv[i];
        out->size[i] = paramv[i + iters];
    }
    return depv[0].guid;
}
#endif /* FULL_SSA */

ocrGuid_t tce_block_sort_2d(u32 paramc, u64* paramv, u32 depc, ocrEdtDep_t depv[]) {
    assert(paramc == 3);
    assert(  depc == 1);
    int i, newi = paramv[0], newj = paramv[1];
    double *dptr = (double*)&paramv[2], amplitude = *dptr;
    ocrGuid_t db;
    tensor_block_desc_t *in, *out;
    in = (tensor_block_desc_t*)depv[0].ptr;
    debug_alloc("alloc %zd", BLOCK_SIZE(in->size[0]*in->size[1]));
    die_if(ocrDbCreate(&db, (void**)&out, BLOCK_SIZE(in->size[0]*in->size[1]), DB_PROP_NONE, NULL_GUID, NO_ALLOC));
    memcpy(out, in, sizeof(*out));
    for(i = 0; i < 2; i++) {
        out->size[i] = in->size[paramv[i]];
        out->pos [i] = in->pos [paramv[i]];
    }
    out->guid = db;
    tce_sort_2(in->data, out->data, in->size[0], in->size[1], newi, newj, amplitude);
    return db;
}

ocrGuid_t tce_block_sort_4d(u32 paramc, u64* paramv, u32 depc, ocrEdtDep_t depv[]) {
    assert(paramc == 5 || paramc == 9);
    assert(  depc == 1);
    int i, newi = paramv[0], newj = paramv[1], newk = paramv[2], newl = paramv[3];
    double *dptr = (double*)&paramv[4], amplitude = *dptr;
    ocrGuid_t db;
    tensor_block_desc_t *in, *out;
    in = (tensor_block_desc_t*)depv[0].ptr;
    if(paramc == 9)
        assert(paramv[5]*paramv[6]*paramv[7]*paramv[8] == in->size[0]*in->size[1]*in->size[2]*in->size[3]);
    debug_alloc("alloc %zd", BLOCK_SIZE(in->size[0]*in->size[1]*in->size[2]*in->size[3]));
    die_if(ocrDbCreate(&db, (void**)&out, BLOCK_SIZE(in->size[0]*in->size[1]*in->size[2]*in->size[3]), DB_PROP_NONE, NULL_GUID, NO_ALLOC));
    memset(out, 0, BLOCK_SIZE(in->size[0]*in->size[1]*in->size[2]*in->size[3]));
    for(i = 0; i < 4; i++) {
        out->pos [i] = in->pos [paramv[i]];
        if(paramc == 9)
            out->size[i] = paramv[5+paramv[i]];
        else
            out->size[i] = in->size[paramv[i]];
    }
    out->guid = db;

    if(paramc == 9)
        tce_sort_4(in->data, out->data, paramv[5], paramv[6], paramv[7], paramv[8], newi, newj, newk, newl, amplitude);
    else
        tce_sort_4(in->data, out->data, in->size[0], in->size[1], in->size[2], in->size[3], newi, newj, newk, newl, amplitude);

    return db;
}

ocrGuid_t tce_block_mm(u32 paramc, u64* paramv, u32 depc, ocrEdtDep_t depv[]) {
    assert(paramc > 5);
    assert(  depc == 2);
    int i;
    int m         =           paramv[0];
    int n         =           paramv[1];
    int k         =           paramv[2];
    double *alpha = (double*)&paramv[3];
    int idxlen    =           paramv[4];
    u64 *idxptr   =          &paramv[5];
    tensor_block_desc_t *A = depv[0].ptr;
    tensor_block_desc_t *B = depv[1].ptr;
    tensor_block_desc_t *C;
    ocrGuid_t db;
    if((m*k != A->size[0] * A->size[1])
    && (m*k != A->size[0] * A->size[1] * A->size[2] * A->size[3]))
        debug("size mismatch in A: m*k=%d*%d=%d, size={%d,%d,%d,%d}",
              m, k, m*k, A->size[0], A->size[1], A->size[2], A->size[3]);
    if((k*n != B->size[0] * B->size[1])
    && (k*n != B->size[0] * B->size[1] * B->size[2] * B->size[3]))
        debug("size mismatch in B: k*n=%d*%d=%d, size={%d,%d,%d,%d}",
              k, n, k*n, B->size[0], B->size[1], B->size[2], B->size[3]);
//    debug("tce_block_mm %d,%d (%d)", m, n, k);
    debug_alloc("alloc %zd", BLOCK_SIZE(m*n));
    die_if(ocrDbCreate(&db, (void**)&C, BLOCK_SIZE(m*n), DB_PROP_NONE, NULL_GUID, NO_ALLOC));
    memset(C, 0, BLOCK_SIZE(m*n));
    for(i = 0; i < idxlen; i++) {
        C-> pos[i] = idxptr[i];
        C->size[i] = idxptr[i+idxlen];
    }
    C->guid = db;
    for(i=0; i<m*k; i++)
        if(isnan(A->data[i]))
            die("NaN in A at position %d", i);
    for(i=0; i<k*n; i++)
        if(isnan(B->data[i]))
            die("NaN in B at position %d", i);

    TCE_DGEMM(CblasTrans, CblasNoTrans, m, n, k, *alpha, A->data, k, B->data, k, 0, C->data, m);

    return db;
}
ocrGuid_t check_block(u32 paramc, u64* paramv, u32 depc, ocrEdtDep_t depv[]) {
#if 1
    assert(paramc == 2);
    assert(  depc == 2);
    int len   = paramv[0];
    int iters = paramv[1];
    tensor_block_desc_t *ref = (tensor_block_desc_t*)depv[0].ptr;
    tensor_block_desc_t *out = (tensor_block_desc_t*)depv[1].ptr;
    int i, bad = 0;
    double epsilon = 1e-10;
//    debug("check_block");
    if(memcmp(out->pos, ref->pos, sizeof(out->pos))) {
        if(iters == 2)
            debug("inner position mismatch for 2d block: out=[%d,%d] ref=[%d,%d]",
                out->pos[0], out->pos[1], ref->pos[0], ref->pos[1]);
        else if(iters == 4)
            debug("inner position mismatch for 4d block: out=[%d,%d,%d,%d] ref=[%d,%d,%d,%d]",
                out->pos[0], out->pos[1], out->pos[2], out->pos[3],
                ref->pos[0], ref->pos[1], ref->pos[2], ref->pos[3]);
        else
            debug("position mismatch for %dd block", iters);
        bad = 1;
    }
    if(memcmp(out->size, ref->size, sizeof(out->size))) {
        if(iters == 2)
            debug("inner size mismatch for 2d block: out=[%d,%d] ref=[%d,%d]",
                out->size[0], out->size[1], ref->size[0], ref->size[1]);
        else if(iters == 4)
            debug("inner size mismatch for 4d block: out=[%d,%d,%d,%d] ref=[%d,%d,%d,%d]",
                out->size[0], out->size[1], out->size[2], out->size[3],
                ref->size[0], ref->size[1], ref->size[2], ref->size[3]);
        else
            debug("size mismatch for %dd block", iters);
        die("size mismatch");
    }
    for(i = 0; i < len; i++) {
        if(isnan(ref->data[i]) || isnan(out->data[i])) {
            debug("Got a NaN! isnan(ref->data[i])=%d isnan(out->data[i])=%d",
                isnan(ref->data[i]), isnan(out->data[i]));
            bad = 1;
        }
        double diff = fabs(ref->data[i] - out->data[i]);
        if(diff > epsilon) {
            if(iters == 2)
                debug("Mismatch: block %d,%d size %dx%d element %d %e != %e",
                        ref->pos [0], ref->pos [1], ref->size[0], ref->size[1],
                        i, ref->data[i], out->data[i]);
            else if(iters == 4)
                debug("Mismatch: block %d,%d,%d,%d size %dx%dx%dx%d element %d %e != %e",
                        ref->pos [0], ref->pos [1], ref-> pos[2], ref->pos [3],
                        ref->size[0], ref->size[1], ref->size[2], ref->size[3],
                        i, ref->data[i], out->data[i]);
            else
                debug("Mismatch: element %d %e != %e", i, ref->data[i], out->data[i]);
            bad = 1;
        }
    }
    if(bad)
        die("mismatch or NaN detected");
//    if(!bad && iters == 2)
//        debug("Ker-CHECK! %dx%d (%d) @ %d,%d compares successfully.",
//              ref->size[0], ref->size[1], len, ref->pos[0], ref->pos[1]);
//    else if(!bad && iters == 4)
//        debug("Ker-CHECK! %dx%dx%dx%d (%d) @ %d,%d,%d,%d compares successfully.",
//              ref->size[0], ref->size[1], ref->size[2], ref->size[3], len,
//              ref-> pos[0], ref-> pos[1], ref-> pos[2], ref-> pos[3]);
//    else if(!bad)
//        debug("Ker-CHECK! %d elements compare successfully.", len);

    return NULL_GUID;
#else
    debug("Not checking block.");
    return NULL_GUID;
#endif
}

ocrGuid_t check_result(u32 paramc, u64* paramv, u32 depc, ocrEdtDep_t depv[]) {
    assert(paramc == 1);
    assert(  depc == 2);
    ocrGuid_t return_event = (ocrGuid_t)paramv[0];
    tensor_t *ref_tensor = (tensor_t*)depv[0].ptr;
    tensor_t *out_tensor = (tensor_t*)depv[1].ptr;
    ocrGuid_t check_template, check_edt, check_return;
    int i, j;
    debug("check_result");
    if(ref_tensor->num_blocks != out_tensor->num_blocks)
        die("num_blocks mismatch: out=%d ref=%d", out_tensor->num_blocks, ref_tensor->num_blocks);
    if(ref_tensor->num_iters != out_tensor->num_iters)
        die("num_iters mismatch: out=%d ref=%d", out_tensor->num_iters, ref_tensor->num_iters);
    ocrEdtTemplateCreate(&check_template, check_block, 2, 2);
    for(i = 0; i < out_tensor->num_blocks; i++) {
        int direct_index = 0, len = 1;
        tensor_block_desc_t *out = &out_tensor->blocks[i];
        tensor_block_desc_t *ref = &ref_tensor->blocks[i];
        for(j = 0; j < out_tensor->num_iters; j++) {
            int local_off, local_len;
            local_off = out_tensor->maxpos[j] - out_tensor->minpos[j] + 1;
            local_len = out->pos[j] - out_tensor->minpos[j];
            if(out->pos[j] < out_tensor->minpos[j]
            || out->pos[j] > out_tensor->maxpos[j])
                die("output block is out of bounds: %d <= %d <= %d", out_tensor->minpos[j], out->pos[j], out_tensor->maxpos[j]);
            direct_index *= local_off;
            direct_index += local_len;
            len *= k_range[out->pos[j]];
        }
        if(memcmp(out->pos, ref->pos, sizeof(out->pos))) {
            if(out_tensor->num_iters == 2)
                die("position mismatch for 2d block %d: out=[%d,%d] ref=[%d,%d]", i,
                    out->pos[0], out->pos[1], ref->pos[0], ref->pos[1]);
            if(out_tensor->num_iters == 4)
                die("position mismatch for 4d block %d: out=[%d,%d,%d,%d] ref=[%d,%d,%d,%d]", i,
                    out->pos[0], out->pos[1], out->pos[2], out->pos[3],
                    ref->pos[0], ref->pos[1], ref->pos[2], ref->pos[3]);
            die("position mismatch for %dd block %d", out_tensor->num_iters, i);
        }
        if(memcmp(out->size, ref->size, sizeof(out->size))) {
            if(out_tensor->num_iters == 2)
                die("size mismatch for 2d block %d: out=[%d,%d] ref=[%d,%d]", i,
                    out->size[0], out->size[1], ref->size[0], ref->size[1]);
            if(out_tensor->num_iters == 4)
                die("size mismatch for 4d block %d: out=[%d,%d,%d,%d] ref=[%d,%d,%d,%d]", i,
                    out->size[0], out->size[1], out->size[2], out->size[3],
                    ref->size[0], ref->size[1], ref->size[2], ref->size[3]);
            die("size mismatch for %dd block %d", out_tensor->num_iters, i);
        }
        ocrEventSatisfySlot(return_event, NULL_GUID, OCR_EVENT_LATCH_INCR_SLOT);
        ocrEdtCreate(&check_edt, check_template, 2, (u64[]){ len, out_tensor->num_iters }, 2, NULL, EDT_PROP_NONE, NULL_GUID, &check_return);
        ocrAddDependence(check_return, return_event, OCR_EVENT_LATCH_DECR_SLOT, DB_MODE_RO);
        ocrAddDependence(ref->guid, check_edt, 0, DB_MODE_RO);
        ocrAddDependence(out->guid, check_edt, 1, DB_MODE_RO);
    }
    ocrEventSatisfySlot(return_event, NULL_GUID, OCR_EVENT_LATCH_DECR_SLOT);
    return NULL_GUID;
}


static int hash_comparator(const void *a_, const void *b_) {
    int *a = (int*)a_, *b = (int*)b_;
    return *a - *b;
}
static int tce_hash_lookup(int *hash, int key) {
    /* essentially the same as the one in tce_hash.F */
    int N = hash[0];

    int *elem = bsearch(&key, &hash[1], N, sizeof(key), hash_comparator);
    if(!elem)
        return -1;
    int o = elem - &hash[1];
    return hash[N+o+1];
}

static ocrGuid_t convert_tensor_to_block_form(int blocks, int iters, int *sizes, int *hash_start, int *out_start, double *data, int *offsets) {
    int done = 0, chunk = 0, i, iter[iters];
    ocrGuid_t tensor_guid;
    tensor_t *tensor;
    debug_alloc("alloc %zd", TENSOR_SIZE(blocks));
    die_if(ocrDbCreate(&tensor_guid, (void**)&tensor, TENSOR_SIZE(blocks), DB_PROP_NONE, NULL_GUID, NO_ALLOC));
    memset(tensor, 0, TENSOR_SIZE(blocks));
    tensor->num_blocks = blocks;
    tensor->num_iters = iters;
    memset(iter, 0, sizeof(iter));
    while(!done) {
        int idx = 0;
        for(i = 0;i < iters; i++) {
            idx *= sizes[i];
            idx += iter[i];
        }
        int offset = tce_hash_lookup(offsets, idx);
        if(offset >= 0) {
            int len = 1;
//            printf("block %d/%d idx %d offset %d:", chunk, blocks, idx, offset);
//            for(i = 0; i < iters; i++)
//                printf("%c%d", i ? 'x' : ' ', k_range[iter[i]]);
//            printf(" @");
//            for(i = 0; i < iters; i++)
//                printf("%c%d", i ? 'x' : ' ', iter[i]);
//            printf("\n");
            tensor_block_desc_t *blockstub = &tensor->blocks[chunk++];
            for(i = 0; i < iters; i++) {
                int tmp = k_range[iter[i]+hash_start[i]];
                len *= tmp;
                blockstub->size[i] = tmp;
                blockstub->pos[i] = iter[i]+out_start[i];
                if(tensor->maxpos[i] < iter[i]+out_start[i])
                    tensor->maxpos[i] = iter[i]+out_start[i];
            }
            tensor_block_desc_t *block;
            debug_alloc("alloc %zd", BLOCK_SIZE(len));
            ocrDbCreate(&blockstub->guid, (void**)&block, BLOCK_SIZE(len), DB_PROP_NONE, NULL_GUID, NO_ALLOC);
            memcpy(block, blockstub, sizeof(*block));
            memcpy(block->data, &data[offset], len * sizeof(double));
//            debug("block %d (%ld) is %dx%dx%dx%d at %d,%d,%d,%d", chunk, blockstub->guid,
//                  blockstub->size[0],blockstub->size[1],blockstub->size[2],blockstub->size[3],
//                  blockstub->pos [0],blockstub->pos [1],blockstub->pos [2],blockstub->pos [3]);
//            debug("block %d (%ld) is %dx%dx%dx%d at %d,%d,%d,%d", chunk, block->guid,
//                  block->size[0],block->size[1],block->size[2],block->size[3],
//                  block->pos [0],block->pos [1],block->pos [2],block->pos [3]);
        }

        /* Advance iterators for the next round */
        for(i = iters-1; i >= 0; i--) {
            iter[i]++;
            if(iter[i] >= sizes[i] && i)
                iter[i] = 0;
            else
                break;
        }
        /* Detect done-ness */
        if(iter[0] >= sizes[0])
            done++;
    }
//    debug("done");
//    for(i = 0; i < tensor->num_blocks; i++) {
//        tensor_block_desc_t *block = &tensor->blocks[i];
//        tensor_block_desc_t *found = find_block(tensor, block->pos);
//        if(block != found)
//            die("mismatch: block=%p found=%p", block, found);
//    }
    return tensor_guid;
}


#define index_pair(i,j) ((i*(i+1))/2+j)
static ocrGuid_t tce_block_intorb(u32 paramc, u64 paramv[], u32 depc, ocrEdtDep_t depv[]) {
    assert(paramc == 4);
    assert(depc == 2);
    int x1 = paramv[0],
        x2 = paramv[1],
        x3 = paramv[2],
        x4 = paramv[3];
    int elements = k_range[x1] * k_range[x2] * k_range[x3] * k_range[x4];
    tensor_t *in         = depv[0].ptr;
    ocrGuid_t *templates = depv[1].ptr;
    tensor_block_desc_t *block;
    int i,j,k,l,ispin,porder[4],sorder[4],size[4],key_alpha[4];
    int ix1,ix2,ix3,ix4,irow,icol;
    bool do_first,do_second;
    ocrGuid_t t_edt, t_event, sum_edt, sum_event, rebadge_edt, rebadge_event, final_output, rv;
    double coeff;
    u64 *uptr = (u64*)&coeff;

    size[0] = k_range[x1];
    size[1] = k_range[x2];
    size[2] = k_range[x3];
    size[3] = k_range[x4];

//    debug("tce_block_intorb: x1=%d x2=%d x3=%d x4=%d", x1, x2, x3, x4);
    // v^{x3<x4}_{x1<x2} => ( x3 x1 | x4 x2 ) - ( x3 x2 | x4 x1 )
    do_first = do_second = 0;

    ispin = k_spin[x3] + k_spin[x4] + k_spin[x1] + k_spin[x2];
    if(ispin == 4) do_first = do_second = 1;
    if(ispin == 8) do_first = do_second = 1;
    if(k_spin[x1] == 1 && k_spin[x2] == 2 && k_spin[x3] == 1 && k_spin[x4] == 2)
        do_first = 1;
    if(k_spin[x1] == 2 && k_spin[x2] == 1 && k_spin[x3] == 2 && k_spin[x4] == 1)
        do_first = 1;
    if(k_spin[x1] == 1 && k_spin[x2] == 2 && k_spin[x3] == 2 && k_spin[x4] == 1)
        do_second = 1;
    if(k_spin[x1] == 2 && k_spin[x2] == 1 && k_spin[x3] == 1 && k_spin[x4] == 2)
        do_second = 1;

    // !do_first && !do_second: v^{x3<x4}_{x1<x2} =>         0         -         0
    // !do_first &&  do_second: v^{x3<x4}_{x1<x2} =>         0         - ( x3 x2 | x4 x1 )
    //  do_first && !do_second: v^{x3<x4}_{x1<x2} => ( x3 x1 | x4 x2 ) -         0
    //  do_first &&  do_second: v^{x3<x4}_{x1<x2} => ( x3 x1 | x4 x2 ) - ( x3 x2 | x4 x1 )

    if(!do_first && !do_second) {
        tensor_block_desc_t *ptr;
        ocrDbCreate(&rv, (void*)&ptr, BLOCK_SIZE(elements), DB_PROP_NONE, NULL_GUID, NO_ALLOC);
        memset(ptr,0,BLOCK_SIZE(elements));
        ptr->pos[0] = x1;
        ptr->pos[1] = x2;
        ptr->pos[2] = x3;
        ptr->pos[3] = x4;
        ptr->size[0] = k_range[x1];
        ptr->size[1] = k_range[x2];
        ptr->size[2] = k_range[x3];
        ptr->size[3] = k_range[x4];
        return rv;
    }

    ocrEventCreate(&rv, OCR_EVENT_STICKY_T, 1);
    ocrEdtCreate(&rebadge_edt, templates[TEMPLATE_REBADGE],
            8, (u64[]){x3, x4, x1, x2, k_range[x3], k_range[x4], k_range[x1], k_range[x2]},
            1, NULL, EDT_PROP_NONE, NULL_GUID, &rebadge_event);
#ifdef FULL_SSA
    ocrAddDependence(rebadge_event, rv, 0, DB_MODE_RO);
#else
    ocrAddDependence(rebadge_event, rv, 0, DB_MODE_ITW);
#endif
    final_output = rebadge_edt;
//    dump_block_by_guid(rv, 4);

//    debug("block tensor=%p do_first=%d do_second=%d x=%d,%d,%d,%d", in, do_first, do_second, x1, x2, x3, x4);

    if (do_first) {
        bool l31s,l42s,lp31p42;
        // first half
        i = max(k_b2am[x1], k_b2am[x3]);
        j = min(k_b2am[x1], k_b2am[x3]);
        k = max(k_b2am[x2], k_b2am[x4]);
        l = min(k_b2am[x2], k_b2am[x4]);
        irow = index_pair(i,j);
        icol = index_pair(k,l);
//        if(irow >= icol)
//            first_h = k-1 + (noa+nva)*(l-1 + (noa+nva)*(i-1 + (noa+nva)*(j-1)));
//        else
//            first_h = i-1 + (noa+nva)*(j-1 + (noa+nva)*(k-1 + (noa+nva)*(l-1)));
        //        key_alpha = first_h;
        if(irow >= icol)
            memcpy(key_alpha,(int[]){j-1,i-1,l-1,k-1},sizeof(key_alpha));
        else
            memcpy(key_alpha,(int[]){l-1,k-1,j-1,i-1},sizeof(key_alpha));
//        debug("...which translates to %d,%d,%d,%d", key_alpha[0], key_alpha[1], key_alpha[2], key_alpha[3]);

        // defining the order
        ix1 = k_b2am[x1];
        ix2 = k_b2am[x2];
        ix3 = k_b2am[x3];
        ix4 = k_b2am[x4];
        l31s = (ix3 < ix1);
        l42s = (ix4 < ix2);
        irow = l31s ? index_pair(ix1,ix3) : index_pair(ix3,ix1);
        icol = l42s ? index_pair(ix2,ix4) : index_pair(ix4,ix2);
        lp31p42 = (irow < icol);

        block = find_block(in, key_alpha);
        if(elements != block->size[0] * block->size[1] * block->size[2] * block->size[3])
            die("size mismatch: got %dx%dx%dx%d @ %d,%d,%d,%d wanted %dx%dx%dx%d @ %d,%d,%d,%d",
                block->size[0],block->size[1],block->size[2],block->size[3],
                key_alpha[0],key_alpha[1],key_alpha[2],key_alpha[3],
                k_range[x1],k_range[x2],k_range[x3],k_range[x4],
                x1, x2, x3, x4);

        if(do_second) {
            ocrEdtCreate(&sum_edt, templates[TEMPLATE_BLOCK_SUM], 1, (u64[]){elements}, 2, NULL, EDT_PROP_NONE, NULL_GUID, &sum_event);
            ocrAddDependence(sum_event, final_output, 0, DB_MODE_RO);
        }

        if(     !lp31p42 && !l31s && !l42s) {
            // --- ( g3 g1 | g4 g2 )
            memcpy(sorder,(int[]){1,0,3,2},sizeof(sorder));
            memcpy(porder,(int[]){3,1,2,0},sizeof(porder));
        } else if(!lp31p42 && !l31s && l42s) {
            // --- ( g3 g1 | g2 g4 )
            memcpy(sorder,(int[]){3,1,0,2},sizeof(sorder));
            memcpy(porder,(int[]){3,0,2,1},sizeof(porder));
        } else if(!lp31p42 && l31s && !l42s) {
            // --- ( g1 g3 | g4 g2 )
            memcpy(sorder,(int[]){1,3,2,0},sizeof(sorder));
            memcpy(porder,(int[]){2,1,3,0},sizeof(porder));
        } else if(!lp31p42 && l31s && l42s) {
            // --- ( g1 g3 | g2 g4 )
            memcpy(sorder,(int[]){3,1,2,0},sizeof(sorder));
            memcpy(porder,(int[]){2,0,3,1},sizeof(porder));
        } else if(lp31p42 && !l31s && !l42s) {
            // --- ( g4 g2 | g3 g1 )
            memcpy(sorder,(int[]){0,2,1,3},sizeof(sorder));
            memcpy(porder,(int[]){1,3,0,2},sizeof(porder));
        } else if(lp31p42 && !l31s && l42s) {
            // --- ( g2 g4 | g3 g1 )
            memcpy(sorder,(int[]){0,2,3,1},sizeof(sorder));
            memcpy(porder,(int[]){1,2,0,3},sizeof(porder));
        } else if(lp31p42 && l31s && !l42s) {
            // --- ( g4 g2 | g1 g3 )
            memcpy(sorder,(int[]){2,0,1,3},sizeof(sorder));
            memcpy(porder,(int[]){0,3,1,2},sizeof(porder));
        } else if(lp31p42 && l31s && l42s) {
            // --- ( g2 g4 | g1 g3 )
            memcpy(sorder,(int[]){2,0,3,1},sizeof(sorder));
            memcpy(porder,(int[]){0,2,1,3},sizeof(porder));
        } else
            die("unhandled permutation");
        coeff = 1.0;

//        debug("...in order {%d,%d,%d,%d}: %ld,%ld,%ld,%ld", porder[0], porder[1], porder[2], porder[3],
//              paramv[porder[0]],paramv[porder[1]],paramv[porder[2]],paramv[porder[3]]);

        ocrEdtCreate(&t_edt, templates[TEMPLATE_SORT_4D],
                     9, (u64[]){porder[0],porder[1],porder[2],porder[3],*uptr,
                                size[sorder[0]],size[sorder[1]],size[sorder[2]],size[sorder[3]]},
                     1, NULL, EDT_PROP_NONE, NULL_GUID, &t_event);

        if(do_second)
            ocrAddDependence(t_event, sum_edt, 0, DB_MODE_RO);
        else
            ocrAddDependence(t_event, final_output, 0, DB_MODE_RO);
        ocrAddDependence(block->guid, t_edt, 0, DB_MODE_RO);

    } // !spin cases

    if(do_second) {
        bool l32s,l41s,lp32p41;
        // second half

        i = max(k_b2am[x2], k_b2am[x3]);
        j = min(k_b2am[x2], k_b2am[x3]);
        k = max(k_b2am[x1], k_b2am[x4]);
        l = min(k_b2am[x1], k_b2am[x4]);
        irow = index_pair(i,j);
        icol = index_pair(k,l);
        if(irow >= icol)
            memcpy(key_alpha,(int[]){j-1,i-1,l-1,k-1},sizeof(key_alpha));
        else
            memcpy(key_alpha,(int[]){l-1,k-1,j-1,i-1},sizeof(key_alpha));
//        debug("...minus %d,%d,%d,%d", key_alpha[0], key_alpha[1], key_alpha[2], key_alpha[3]);

        // defining the order
        ix2 = k_b2am[x2];
        ix1 = k_b2am[x1];
        ix3 = k_b2am[x3];
        ix4 = k_b2am[x4];
        l32s = (ix3 < ix2);
        l41s = (ix4 < ix1);
        irow = l32s ? index_pair(ix2,ix3) : index_pair(ix3,ix2);
        icol = l41s ? index_pair(ix1,ix4) : index_pair(ix4,ix1);
        lp32p41 = (irow < icol);

        block = find_block(in, key_alpha);
        if(elements != block->size[0] * block->size[1] * block->size[2] * block->size[3])
            die("size mismatch: got %dx%dx%dx%d @ %d,%d,%d,%d wanted %dx%dx%dx%d @ %d,%d,%d,%d",
                block->size[0],block->size[1],block->size[2],block->size[3],
                key_alpha[0],key_alpha[1],key_alpha[2],key_alpha[3],
                k_range[x1],k_range[x2],k_range[x3],k_range[x4],
                x1, x2, x3, x4);

        if(!lp32p41 && !l32s && !l41s) {
            // --- ( g3 g2 | g4 g1 )
            memcpy(sorder,(int[]){0,3,1,2},sizeof(sorder));
            memcpy(porder,(int[]){3,1,0,2},sizeof(porder));
        } else if(!lp32p41 && !l32s && l41s) {
            // --- ( g3 g2 | g1 g4 )
            memcpy(sorder,(int[]){1,0,3,2},sizeof(sorder));
            memcpy(porder,(int[]){3,0,1,2},sizeof(porder));
        } else if(!lp32p41 && l32s && !l41s) {
            // --- ( g2 g3 | g4 g1 )
            memcpy(sorder,(int[]){0,3,2,1},sizeof(sorder));
            memcpy(porder,(int[]){2,1,0,3},sizeof(porder));
        } else if(!lp32p41 && l32s && l41s) {
            // --- ( g2 g3 | g1 g4 )
            memcpy(sorder,(int[]){0,3,2,1},sizeof(sorder));
            memcpy(porder,(int[]){2,0,1,3},sizeof(porder));
        } else if(lp32p41 && !l32s && !l41s) {
            // --- ( g4 g1 | g3 g2 )
            memcpy(sorder,(int[]){1,2,0,3},sizeof(sorder));
            memcpy(porder,(int[]){1,3,2,0},sizeof(porder));
        } else if(lp32p41 && l32s && !l41s) {
            // --- ( g4 g1 | g2 g3 )
            memcpy(sorder,(int[]){2,1,0,3},sizeof(sorder));
            memcpy(porder,(int[]){0,3,2,1},sizeof(porder));
        } else if(lp32p41 && !l32s && l41s) {
            // --- ( g1 g4 | g3 g2 )
            memcpy(sorder,(int[]){1,0,3,2},sizeof(sorder));
            memcpy(porder,(int[]){1,2,3,0},sizeof(porder));
        } else if(lp32p41 && l32s && l41s) {
            // --- ( g1 g4 | g2 g3 )
            memcpy(sorder,(int[]){2,1,0,3},sizeof(sorder));
            memcpy(porder,(int[]){0,2,3,1},sizeof(porder));
        } else
            die("unhandled permutation");
        coeff = -1.0;
//        debug("...in order {%d,%d,%d,%d}: %ld,%ld,%ld,%ld", porder[0], porder[1], porder[2], porder[3],
//              paramv[porder[0]],paramv[porder[1]],paramv[porder[2]],paramv[porder[3]]);
        ocrEdtCreate(&t_edt, templates[TEMPLATE_SORT_4D],
                     9, (u64[]){porder[0],porder[1],porder[2],porder[3],*uptr,size[sorder[0]],size[sorder[1]],size[sorder[2]],size[sorder[3]]},
                     1, NULL, EDT_PROP_NONE, NULL_GUID, &t_event);

        if(do_first)
            ocrAddDependence(t_event, sum_edt, 1, DB_MODE_RO);
        else
            ocrAddDependence(t_event, final_output, 0, DB_MODE_RO);
        ocrAddDependence(block->guid, t_edt, 0, DB_MODE_RO);

    } // !spin cases

    return rv;
}
static ocrGuid_t convert_intorb_tensor_to_block_form(int *sizes, int *hash_start, int *out_start, double *data) {
    const int iters = 4;
    int done = 0, chunk = 0, iter[4];
    ocrGuid_t tensor_guid;
    tensor_t *tensor;
    int i, blocks, offset;
    memset(iter, 0, sizeof(iter));
    blocks = offset = 0;
    while(iter[0] < sizes[0]) {
        if(k_spin_alpha[iter[0]]+k_spin_alpha[iter[1]] == k_spin_alpha[iter[2]]+k_spin_alpha[iter[3]]) {
            if((k_sym_alpha[iter[0]] ^ k_sym_alpha[iter[1]] ^ k_sym_alpha[iter[2]] ^ k_sym_alpha[iter[3]]) == irrep_v) {
                if(index_pair(iter[1],iter[0]) >= index_pair(iter[3],iter[2])) {
//                    debug("block %d: %d,%d,%d,%d", blocks, iter[0], iter[1], iter[2], iter[3]);
                    blocks++;
                }
            }
        }
        /* Advance iterators for the next round */
        for(i = iters-1; i >= 0; i--) {
            iter[i]++;
            if(iter[i] >= sizes[i] && i) {
                iter[i] = 0;
            } else {
                if(!(i & 1) && iter[i+1] == 0)
                    iter[i+1] = iter[i];
                break;
            }
        }
    }
    debug_alloc("alloc %zd", TENSOR_SIZE(blocks));
    die_if(ocrDbCreate(&tensor_guid, (void**)&tensor, TENSOR_SIZE(blocks), DB_PROP_NONE, NULL_GUID, NO_ALLOC));
    memset(tensor, 0, TENSOR_SIZE(blocks));
    tensor->num_blocks = blocks;
    tensor->num_iters = iters;
    memset(iter, 0, sizeof(iter));
    while(!done) {
        int real = 0;
        if(k_spin_alpha[iter[0]]+k_spin_alpha[iter[1]] == k_spin_alpha[iter[2]]+k_spin_alpha[iter[3]])
            if((k_sym_alpha[iter[0]] ^ k_sym_alpha[iter[1]] ^ k_sym_alpha[iter[2]] ^ k_sym_alpha[iter[3]]) == irrep_v)
                if(index_pair(iter[1],iter[0]) >= index_pair(iter[3],iter[2]))
                    real++;
        if(real) {
            int len = 1;
//            if(iters == 4)
//                debug("block %d/%d offset %d: %dx%dx%dx%d @ %d,%d,%d,%d",
//                      chunk, blocks, offset,
//                      k_range[iter[0]], k_range[iter[1]], k_range[iter[2]], k_range[iter[3]],
//                      iter[0], iter[1], iter[2], iter[3]);
            tensor_block_desc_t *blockstub = &tensor->blocks[chunk++];
            if(chunk > blocks)
                die("block overflow");
            for(i = 0; i < iters; i++) {
                int tmp;
                /* k_range values (and pretty much everything else in this program) are indexed like this:
                 * { [orbital spin A indices], [orbital spin B indices], [electron spin A indices], [electron spin B indices] }
                 * or: {[1..noa, 1..nob, 1..nva, 1..nvb]}
                 * However, in the intorb case, the v2 input hash is spin-independent, and indexed like this:
                 * { [orbital indices], [electron indices] }
                 * or: {[1..noa, 1..nva]}
                 * To keep the indices consistent and reduce confusion later on,
                 * we convert the input indexes to:
                 * { [orbital spin A indices], [gap], [electron spin A indices], [gap] }
                 * or: {[1..noa, gap, 1..nva, gap]}
                 * Which is compatible with the indices of k_range and everything else. */
                if(iter[i] >= noa)
                    tmp = k_range[iter[i]+hash_start[i]+nob];
                else
                    tmp = k_range[iter[i]+hash_start[i]];
                len *= tmp;
                blockstub->size[i] = tmp;
                blockstub->pos[i] = iter[i]+out_start[i];
                if(tensor->maxpos[i] < iter[i]+out_start[i])
                    tensor->maxpos[i] = iter[i]+out_start[i];
            }
            tensor_block_desc_t *block;
            debug_alloc("alloc %zd", BLOCK_SIZE(len));
            ocrDbCreate(&blockstub->guid, (void**)&block, BLOCK_SIZE(len), DB_PROP_NONE, NULL_GUID, NO_ALLOC);
            memcpy(block, blockstub, sizeof(*block));
            memcpy(block->data, &data[offset], len * sizeof(double));
            for(i = 0; i < len; i++)
                if(isnan(block->data[i]))
                    die("NaN in input data?");
//            debug("block %d (%ld) is %dx%dx%dx%d at %d,%d,%d,%d", chunk, block->guid,
//                  block->size[0],block->size[1],block->size[2],block->size[3],
//                  block->pos [0],block->pos [1],block->pos [2],block->pos [3]);
            offset += len;
        }

        /* Advance iterators for the next round */
        for(i = iters-1; i >= 0; i--) {
            iter[i]++;
            if(iter[i] >= sizes[i] && i) {
                iter[i] = 0;
            } else {
                if(!(i & 1) && iter[i+1] == 0)
                    iter[i+1] = iter[i];
                break;
            }
        }
        /* Detect done-ness */
        if(iter[0] >= sizes[0])
            done++;
    }
    debug("done");
    for(i = 0; i < tensor->num_blocks; i++) {
        tensor_block_desc_t *block = &tensor->blocks[i];
        tensor_block_desc_t *found = find_block(tensor, block->pos);
        if(block != found)
            die("mismatch: block=%p found=%p", block, found);
        die_if(!block->guid);
    }
    return tensor_guid;
}

ocrGuid_t done(u32 paramc, u64 *paramv, u32 depc, ocrEdtDep_t *depv) {
    debug("done");
    ocrShutdown();
    return NULL_GUID;
}

ocrGuid_t followup(u32 paramc, u64 *paramv, u32 depc, ocrEdtDep_t *depv) {
    assert(paramc == 0);
    assert(depc == 4);
    tensor_t //*ref_r1_tensor = depv[0].ptr,
             *out_r1_tensor = depv[1].ptr,
             //*ref_r2_tensor = depv[2].ptr,
             *out_r2_tensor = depv[3].ptr;
    ocrGuid_t ref_r1_guid = depv[0].guid,
              out_r1_guid = depv[1].guid,
              ref_r2_guid = depv[2].guid,
              out_r2_guid = depv[3].guid;
    ocrGuid_t return_event, check_template, check_edt, done_template, done_edt;

    debug("followup");
    ocrEventCreate(&return_event, OCR_EVENT_LATCH_T, 0);
    ocrEventSatisfySlot(return_event, NULL_GUID, OCR_EVENT_LATCH_INCR_SLOT);

    ocrEdtTemplateCreate(&done_template, done, 0, 1);
    ocrEdtTemplateCreate(&check_template, check_result, 1, 2);
    ocrEdtCreate(&done_edt, done_template, 0, NULL, 1, (ocrGuid_t[]){return_event}, EDT_PROP_NONE, NULL_GUID, NULL);

    if(out_r1_tensor) {
        ocrEventSatisfySlot(return_event, NULL_GUID, OCR_EVENT_LATCH_INCR_SLOT);
        ocrEdtCreate(&check_edt, check_template, 1, (u64[]){return_event}, 2, (ocrGuid_t[]){ref_r1_guid, out_r1_guid}, EDT_PROP_NONE, NULL_GUID, NULL);
    }

    if(out_r2_tensor) {
        ocrEventSatisfySlot(return_event, NULL_GUID, OCR_EVENT_LATCH_INCR_SLOT);
        ocrEdtCreate(&check_edt, check_template, 1, (u64[]){return_event}, 2, (ocrGuid_t[]){ref_r2_guid, out_r2_guid}, EDT_PROP_NONE, NULL_GUID, NULL);
    }

    /* If neither output was provided, that means debugging is happening 
     * elsewhere in the application graph, just let this part hang */
    if(out_r1_tensor || out_r2_tensor)
        ocrEventSatisfySlot(return_event, NULL_GUID, OCR_EVENT_LATCH_DECR_SLOT);

    return NULL_GUID;
}

static ocrGuid_t dump_block(u32 paramc, u64 paramv[], u32 depc, ocrEdtDep_t depv[]) {
    assert(paramc >= 1);
    assert(depc   == 1);
    int num_iters = paramv[0];
    tensor_block_desc_t *in_block = depv[0].ptr;
    int i, size;
    size = 1;
    for(i = 0; i < num_iters; i++) {
        size *= in_block->size[i];
    }

    if(paramc > 1) {
        if(num_iters == 2)
            debug("dump_block: %dx%d (%d) @ %d,%d (expected %ldx%ld @ %ld,%ld)",
                  in_block->size[0], in_block->size[1], size,
                  in_block-> pos[0], in_block-> pos[1],
                  paramv[1], paramv[2], paramv[3], paramv[4]);
        else if(num_iters == 4)
            debug("dump_block: %dx%dx%dx%d (%d) @ %d,%d,%d,%d (expected %ldx%ldx%ldx%ld @ %ld,%ld,%ld,%ld)",
                  in_block->size[0], in_block->size[1], in_block->size[2], in_block->size[3], size,
                  in_block-> pos[0], in_block-> pos[1], in_block-> pos[2], in_block-> pos[3],
                  paramv[1], paramv[2], paramv[3], paramv[4], paramv[5], paramv[6], paramv[7], paramv[8]);
        else
            debug("dump_block with %d iters, %d elements", num_iters, size);
    }
    else {
        if(num_iters == 2)
            debug("dump_block: %dx%d (%d) @ %d,%d",
                  in_block->size[0], in_block->size[1], size,
                  in_block-> pos[0], in_block-> pos[1]);
        else if(num_iters == 4)
            debug("dump_block: %dx%dx%dx%d (%d) @ %d,%d,%d,%d",
                  in_block->size[0], in_block->size[1], in_block->size[2], in_block->size[3], size,
                  in_block-> pos[0], in_block-> pos[1], in_block-> pos[2], in_block-> pos[3]);
        else
            debug("dump_block with %d iters, %d elements", num_iters, size);
    }

    for(i = 0; i < size; i++)
        if(isnan(in_block->data[i]))
            die("got NaN in element %d", i);

    for(i = 0; i < size; i++)
        debug("in_block->data[%d] = %g", i, in_block->data[i]);

    return NULL_GUID;
}

static ocrGuid_t dump_tensor(u32 paramc, u64 paramv[], u32 depc, ocrEdtDep_t depv[]) {
    assert(paramc == 1);
    assert(depc   == 1);
    int i;
    ocrGuid_t block_template = paramv[0];
    tensor_t *in      = depv[0].ptr;
    ocrGuid_t in_guid = depv[0].guid;
    ocrGuid_t block_edt;
    int num_iters = in->num_iters;
    debug("dump_tensor called for guid %ld, %d blocks", in_guid, in->num_blocks);
    for(i = 0; i < in->num_blocks; i++) {
        tensor_block_desc_t *in_block = &in->blocks[i];
        if(num_iters == 2)
            debug("scheduling dump_block: %dx%d @ %d,%d",
                  in_block->size[0], in_block->size[1],
                  in_block-> pos[0], in_block-> pos[1]);
        else if(num_iters == 4)
            debug("scheduling dump_block: %dx%dx%dx%d @ %d,%d,%d,%d",
                  in_block->size[0], in_block->size[1], in_block->size[2], in_block->size[3],
                  in_block-> pos[0], in_block-> pos[1], in_block-> pos[2], in_block-> pos[3]);
        else
            die("can't handle %d iters", num_iters);
        if(num_iters == 2)
            ocrEdtCreate(&block_edt, block_template, 5, (u64[]){in->num_iters,
                    in_block->size[0], in_block->size[1],
                    in_block-> pos[0], in_block-> pos[1]},
                    1, &in_block->guid, EDT_PROP_NONE, NULL_GUID, NULL);
        else if(num_iters == 4)
            ocrEdtCreate(&block_edt, block_template, 9, (u64[]){in->num_iters,
                    in_block->size[0], in_block->size[1], in_block->size[2], in_block->size[3],
                    in_block-> pos[0], in_block-> pos[1], in_block-> pos[2], in_block-> pos[3]},
                    1, &in_block->guid, EDT_PROP_NONE, NULL_GUID, NULL);
//        break;
    }
    return NULL_GUID;
}

void dump_tensor_by_guid(ocrGuid_t guid) {
    ocrGuid_t dump_tensor_template, dump_tensor_edt, dump_block_template;
    ocrEdtTemplateCreate(&dump_block_template, dump_block, EDT_PARAM_UNK, 1);
    ocrEdtTemplateCreate(&dump_tensor_template, dump_tensor, 1, 1);
    ocrEdtCreate(&dump_tensor_edt, dump_tensor_template, 1, (u64[]){dump_block_template}, 1, &guid, EDT_PROP_NONE, NULL_GUID, NULL);
}

void dump_block_by_guid(ocrGuid_t guid, int num_iters) {
    ocrGuid_t dump_block_template, dump_block_edt;
    ocrEdtTemplateCreate(&dump_block_template, dump_block, 1, 1);
    ocrEdtCreate(&dump_block_edt, dump_block_template, 1, (u64[]){num_iters}, 1, &guid, EDT_PROP_NONE, NULL_GUID, NULL);
}
