/* Copyright (C) 2014 ET International, Inc. */

#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <math.h>
#include "tce.h"

#define CHECK_R1
#define CHECK_R2

#define EPSILON 1e-15

/* The extra nesting is to convince cpp to generate a function name like cc2_t1,
 * rather than MODEL_t1 or errors like "stray ‘##’ in program" and
 * "unknown type name ‘cc2’" */
#define _FUNC2(model,suffix) model ## _ ## suffix
#define _FUNC1(model,suffix) _FUNC2(model,suffix)
#define  FUNC(suffix) _FUNC1(MODEL,suffix)

/* Similarly, the extra nesting convinces cpp to generate a string like "cc2",
 * rather than "macro" or "MODEL" */
#define _STRINGIFY1(macro) #macro
#define STRINGIFY(macro) _STRINGIFY1(macro)

CODELET_IMPORT(FUNC(t1));
CODELET_IMPORT(FUNC(t2));

#define ENTRIES(a) (sizeof(a)/sizeof(a[0]))
static char *scalar_names[] = (char*[]) {
    "noa",
    "nob",
    "nva",
    "nvb",
    "noab",
    "nvab",
    "io_v2",
    "intorb",
    "size_f1",
    "size_t1",
    "size_t2",
    "size_v2",
    "restricted",
};
enum {
    si_noa = 0,
    si_nob,
    si_nva,
    si_nvb,
    si_noab,
    si_nvab,
    si_io_v2,
    si_intorb,
    si_size_f1,
    si_size_t1,
    si_size_t2,
    si_size_v2,
    si_restricted,
    NUM_SCALARS
};
static char *vector_names[] = (char*[]) {
    "k_sym",
    "k_b2am",
    "k_spin",
    "k_alpha",
    "k_range",
    "k_offset",
    "k_f1_offset",
    "k_t1_offset",
    "k_t2_offset",
    "k_v2_offset",
    "k_sym_alpha",
    "k_spin_alpha",
    "k_range_alpha",
    "k_v2_alpha_offset",
};
enum {
    vi_sym = 0,
    vi_b2am,
    vi_spin,
    vi_alpha,
    vi_range,
    vi_offset,
    vi_f1_offset,
    vi_t1_offset,
    vi_t2_offset,
    vi_v2_offset,
    vi_sym_alpha,
    vi_spin_alpha,
    vi_range_alpha,
    vi_v2_alpha_offset,
    NUM_VECTORS
};
static char *tensor_names[] = (char*[]) {
    "f1",
    "v2",
    "t1",
    "t2",
    "r1",
    "r2",
};
enum {/* Note: this determines the order of command line arguments. */
    ti_f1 = 0,
    ti_v2,
    ti_t1,
    ti_t2,
    ti_r1,
    ti_r2,
    NUM_TENSORS
};

int *k_sym;
int *k_b2am;
int *k_spin;
int *k_alpha;
int *k_range;
int *k_offset;
int *k_sym_alpha;
int *k_spin_alpha;
int *k_range_alpha;
int *k_v2_alpha_offset;
int noab, nvab, noa, nob, nva, nvb, io_v2;
bool restricted, intorb;

double FACTORIAL[20];
int *scalars, *vector_sizes, **vectors, *tensor_sizes;
double **tensors;

void tce_hash_v2_prepare(const int *hash, int M);

typedef struct {
    int argc;
    char **argv;
} main_args_t;
CODELET_DECL(followup);
CODELET_IMPL_BEGIN_NOCANCEL(main)
    main_args_t *args = (main_args_t*)INPUT;
    int argc    = args->argc;
    char **argv = args->argv;
    FILE *f;
    int i, j;
    char line[256];
    scalars      = calloc(NUM_SCALARS, sizeof(int));
    vector_sizes = calloc(NUM_VECTORS, sizeof(int));
    vectors      = calloc(NUM_VECTORS, sizeof(int*));
    tensor_sizes = calloc(NUM_TENSORS, sizeof(int));
    tensors      = calloc(NUM_TENSORS, sizeof(double*));
    if(!scalars || !vector_sizes || !vectors || !tensor_sizes)
        die("malloc failure");
    if(argc < 8)
        die("argc is %d.  Usage: %s <params> <f1> <v2> <t1> <t2> <r1> <r2>", argc, argv[0]);
    f = fopen(argv[1], "r");
    if(!f)
        die("Cannot open params file %s", argv[1]);
    if(!fgets(line, sizeof(line), f))
        die("Could not read line of params file");
    /* parse scalar constants */
    uint64_t mask = 0;
    while(!strchr(line, '[')) {
        /* line[] contains something like "size_v2=   7970724", parse it. */
        for(i = 0; i < NUM_SCALARS; i++) {
            if(!strncmp(line, scalar_names[i], strlen(scalar_names[i])) && (
                    line[strlen(scalar_names[i])] == ' '
                 || line[strlen(scalar_names[i])] == '='))
                break;
        }
        if(i == NUM_SCALARS)
            die("Could not find scalar variable name in line \"%s\"", line);
        mask |= (1ULL<<i);
        char *equals = strchr(line,'=');
        if(!equals)
            die("Could not find equal sign in line \"%s\"", line);
        scalars[i] = strtol(equals+1,NULL,0);

        if(!fgets(line, sizeof(line), f))
            die("Could not read line of params file");
    }
    for(i = 0; i < NUM_SCALARS; i++) {
        if(!(mask & (1ULL<<i)))
            printf("scalar \"%s\" not found in params file, defaulting to 0.\n", scalar_names[i]);
    }
    /* parse vector constants */
    mask = 0;
    while(1) {
        /* line[] contains something like "k_sym[18]=", parse it. */
        for(i = 0; i < NUM_VECTORS; i++) {
            if(!strncmp(line, vector_names[i], strlen(vector_names[i]))
            && line[strlen(vector_names[i])] == '[')
                break;
        }
        if(i == NUM_VECTORS)
            die("Could not find vector variable name in line \"%s\"", line);
        mask |= (1ULL<<i);
        char *bracket = strchr(line,'[');
        if(!bracket)
            die("Could not find square brackets in line \"%s\"", line);
        vector_sizes[i] = strtol(bracket+1,NULL,0);
        vectors[i] = malloc(sizeof(vectors[i][0])*vector_sizes[i]);
        if(!vectors[i])
            die("Could not malloc buffer of size %zd for vector %s (%d)",
                sizeof(vectors[i][0])*vector_sizes[i], vector_names[i], i);
        for(j = 0; j < vector_sizes[i]; j++) {
            if(!fgets(line, sizeof(line), f))
                die("Could not read element %d of vector %s (%d)",
                    j, vector_names[i], i);
            /* line[] contains something like "     1     0", parse it. */
            char *ptr;
            int index, value;
            index = strtol(line, &ptr, 0);
            value = strtol(ptr , NULL, 0);
            if(j != index-1)
                die("index mismatch in %s: %d != %d", vector_names[i],j+1,index);

            vectors[i][j] = value;
        }

        if(!fgets(line, sizeof(line), f)) {
            fclose(f);
            break;
        }
    }
    for(i = 0; i < NUM_VECTORS; i++) {
        if(!(mask & (1ULL<<i)))
            printf("vector \"%s\" not found in params file, defaulting to NULL.\n", vector_names[i]);
    }
    /* read tensors */
    tensor_sizes[0] = scalars[si_size_f1]; /* size_f1 */
    tensor_sizes[1] = scalars[si_size_v2]; /* size_v2 */
    tensor_sizes[2] = scalars[si_size_t1]; /* size_t1 */
    tensor_sizes[3] = scalars[si_size_t2]; /* size_t2 */
    tensor_sizes[4] = scalars[si_size_t1]; /* r1 has the same size as t1 */
    tensor_sizes[5] = scalars[si_size_t2]; /* r2 has the same size as t2 */
    for(i = 0; i < 6; i++) {
        f = fopen(argv[2+i], "r");
        if(!f)
            die("Cannot open %s file %s", tensor_names[i], argv[2+i]);
        tensors[i] = malloc(sizeof(tensors[i][0]) * tensor_sizes[i]);
        if(!tensors[i])
            die("Could not malloc buffer of size %zd for tensor %s (%d)",
                sizeof(tensors[i][0])*tensor_sizes[i], tensor_names[i], i);
        int rv = fread(tensors[i], sizeof(tensors[i][0]), tensor_sizes[i], f);
        if(rv != tensor_sizes[i])
            die("reading tensor %s (%d), fread() returned %d, wanted %d",
                    tensor_names[i], i, rv, tensor_sizes[i]);
        fclose(f);
    }
    /* Set up global scalars */
    noa        = scalars[si_noa];
    nob        = scalars[si_nob];
    nva        = scalars[si_nva];
    nvb        = scalars[si_nvb];
    noab       = scalars[si_noab];
    nvab       = scalars[si_nvab];
    io_v2      = scalars[si_io_v2];
    intorb     = scalars[si_intorb];
    restricted = scalars[si_restricted];
    /* Set up global vectors */
    k_sym             = vectors[vi_sym];
    k_b2am            = vectors[vi_b2am];
    k_spin            = vectors[vi_spin];
    k_alpha           = vectors[vi_alpha];
    k_range           = vectors[vi_range];
    k_offset          = vectors[vi_offset];
    k_sym_alpha       = vectors[vi_sym_alpha];
    k_spin_alpha      = vectors[vi_spin_alpha];
    k_range_alpha     = vectors[vi_range_alpha];
    k_v2_alpha_offset = vectors[vi_v2_alpha_offset];
    FACTORIAL[0] = 1;
    for(i = 1; i < ENTRIES(FACTORIAL); i++)
        FACTORIAL[i] = FACTORIAL[i-1] * i;

    if(intorb)
        tce_hash_v2_prepare(k_v2_alpha_offset, 10);

#if defined(CHECK_R1) || defined(CHECK_R2)
    argument_list_t *followup_args = malloc(ARGUMENT_LIST_SIZE(2));
    *followup_args = ARGUMENT_INIT(2,&CODELET(followup),NULL,followup_args,&CODELET(free_arg_list),followup_args);
    for(i = 0; i < 2; i++)
        followup_args->args[i].head = followup_args;
    debug("followup=%p", followup_args);
#endif /* CHECK_R1 || CHECK_R2 */
#ifdef CHECK_R1
    /* Call cc2_t1 or ccsd_t1 or whatever */
    argument_list_t *t1_args = malloc(ARGUMENT_LIST_SIZE(9));
    *t1_args = ARGUMENT_INIT(9,&CODELET(FUNC(t1)),NULL,t1_args,&CODELET(satisfy),&followup_args->args[0], .len = tensor_sizes[ti_t1]);
    for(i = 0; i < 9; i++)
        t1_args->args[i].head = t1_args;
    printf("Calling " STRINGIFY(MODEL) "_t1 (size=%d)\n", scalars[si_size_t1]);
    swarm_schedule(&CODELET(satisfy),&t1_args->args[0], tensors[ti_f1], NULL, NULL);
    swarm_schedule(&CODELET(satisfy),&t1_args->args[1], tensors[ti_t1], NULL, NULL);
    swarm_schedule(&CODELET(satisfy),&t1_args->args[2], tensors[ti_t2], NULL, NULL);
    swarm_schedule(&CODELET(satisfy),&t1_args->args[3], tensors[ti_v2], NULL, NULL);
    swarm_schedule(&CODELET(satisfy),&t1_args->args[4], vectors[vi_t1_offset], NULL, NULL);
    swarm_schedule(&CODELET(satisfy),&t1_args->args[5], vectors[vi_f1_offset], NULL, NULL);
    swarm_schedule(&CODELET(satisfy),&t1_args->args[6], vectors[vi_t1_offset], NULL, NULL);
    swarm_schedule(&CODELET(satisfy),&t1_args->args[7], vectors[vi_t2_offset], NULL, NULL);
    swarm_schedule(&CODELET(satisfy),&t1_args->args[8], vectors[vi_v2_offset], NULL, NULL);
#else
    swarm_schedule(&CODELET(satisfy),&followup_args->args[0], NULL, NULL, NULL);
#endif

#ifdef CHECK_R2
    /* Call cc2_t2 or ccsd_t2 or whatever */
    argument_list_t *t2_args = malloc(ARGUMENT_LIST_SIZE(9));
    *t2_args = ARGUMENT_INIT(9,&CODELET(FUNC(t2)),NULL,t2_args,&CODELET(satisfy),&followup_args->args[1], .len = tensor_sizes[ti_t2]);
    for(i = 0; i < 9; i++)
        t2_args->args[i].head = t2_args;
    printf("Calling " STRINGIFY(MODEL) "_t2 (size=%d)\n", scalars[si_size_t2]);
    swarm_schedule(&CODELET(satisfy),&t2_args->args[0], tensors[ti_f1], NULL, NULL);
    swarm_schedule(&CODELET(satisfy),&t2_args->args[1], tensors[ti_t1], NULL, NULL);
    swarm_schedule(&CODELET(satisfy),&t2_args->args[2], tensors[ti_t2], NULL, NULL);
    swarm_schedule(&CODELET(satisfy),&t2_args->args[3], tensors[ti_v2], NULL, NULL);
    swarm_schedule(&CODELET(satisfy),&t2_args->args[4], vectors[vi_t2_offset], NULL, NULL);
    swarm_schedule(&CODELET(satisfy),&t2_args->args[5], vectors[vi_f1_offset], NULL, NULL);
    swarm_schedule(&CODELET(satisfy),&t2_args->args[6], vectors[vi_t1_offset], NULL, NULL);
    swarm_schedule(&CODELET(satisfy),&t2_args->args[7], vectors[vi_t2_offset], NULL, NULL);
    swarm_schedule(&CODELET(satisfy),&t2_args->args[8], vectors[vi_v2_offset], NULL, NULL);
#else
    swarm_schedule(&CODELET(satisfy),&followup_args->args[1], NULL, NULL, NULL);
#endif /* CHECK_R2 */
CODELET_IMPL_END;

CODELET_IMPL_BEGIN_NOCANCEL(followup)
    argument_list_t *list = INPUT;
    double *my_r1 = list->args[0].buffer;
    double *my_r2 = list->args[1].buffer;
    int i, rv = 0;

#ifdef CHECK_R1
    /* Check r1 */
    printf("Checking " STRINGIFY(MODEL) "_t1\n");
    for(i = 0; i < scalars[si_size_t1]; i++) {

        if(fabs(tensors[ti_r1][i] - my_r1[i]) > EPSILON) {
            rv++;
            if(rv == 50) {
                debug("[more t1 errors suppressed.]");
                continue;
            } else if(rv < 50)
                debug(STRINGIFY(MODEL) "_t1 output index %d differs: (expected, got) %e, %e",
                      i, tensors[ti_r1][i], my_r1[i]);
        }
    }
#endif /* CHECK_R1 */

    if(rv > 50)
        rv = 50;

#ifdef CHECK_R2
    /* Check r2 */
    printf("Checking " STRINGIFY(MODEL) "_t2\n");
    for(i = 0; i < scalars[si_size_t2]; i++) {
        if(fabs(tensors[ti_r2][i] - my_r2[i]) > EPSILON) {
            rv++;
            if(rv == 50) {
                debug("[more t2 errors suppressed.]");
                continue;
            } else if(rv < 50)
                debug(STRINGIFY(MODEL) "_t2 output index %d differs: (expected, got) %e, %e",
                        i, tensors[ti_r2][i], my_r2[i]);
        }
    }
#endif /* CHECK_R2 */

    if(rv > 50)
        rv = 50;
    debug("rv=%d", rv);
    swarm_dispatch(&CODELET(free_arg_list), list, NULL, NEXT, NEXT_THIS);
    swarm_shutdownRuntime(NULL);
CODELET_IMPL_END;

int main(int argc, char **argv) {
    int i;
    main_args_t args;
    args.argc = argc;
    args.argv = argv;
//    tracing_hook_into_swarm();
    swarm_posix_enterRuntime(NULL, &CODELET(main), NULL, (void*)&args);
//    tracing_emit_log("tracing.log");
    free(scalars);
    free(vector_sizes);
    free(tensor_sizes);
    for(i = 0; i < NUM_VECTORS; i++)
        free(vectors[i]);
    for(i = 0; i < NUM_TENSORS; i++)
        free(tensors[i]);
    free(vectors);
    free(tensors);
    return 0;
}

/* Straight translations of src/tce/tce_restricted.F, minus the int_mb nonsense */
void tce_restricted_2(int a1b, int a2b, int *b1b, int *b2b) {
    if(restricted && k_spin[a1b]+k_spin[a2b] == 4) {
        *b1b = k_alpha[a1b] - 1;
        *b2b = k_alpha[a2b] - 1;
    } else {
        *b1b = a1b;
        *b2b = a2b;
    }
}
void tce_restricted_4(int a1b, int a2b, int a3b, int a4b, int *b1b, int *b2b, int *b3b, int *b4b) {
    if(restricted && k_spin[a1b]+k_spin[a2b]+k_spin[a3b]+k_spin[a4b] == 8) {
        *b1b = k_alpha[a1b] - 1;
        *b2b = k_alpha[a2b] - 1;
        *b3b = k_alpha[a3b] - 1;
        *b4b = k_alpha[a4b] - 1;
    } else {
        *b1b = a1b;
        *b2b = a2b;
        *b3b = a3b;
        *b4b = a4b;
    }
}


/* Rearrange the 2d input array, multiplying values by the amplitude factor.
 * [a,b] defines the length, along each dimension, of the input arrays.
 * [i,j] defines the target index order.  [0,1] is a direct copy; [1,0] transposes. */
void tce_sort_2(double *in, double *out, int a, int b, int i, int j, double factor) {
    /* more-or-less direct translation of tce_sort2.F */
    int pos[2],len[2],ia,ib,j1,j2;
    ia = 0;
    if(i == 0 && j == 1) {
        /* no permutation, just copy and apply the scale factor */
        for(ia = 0; ia < a * b; ia++)
            out[ia] = in[ia] * factor;
        return;
    }
    len[0] = a;
    len[1] = b;
    for(j1 = 0; j1 < a; j1++) {
        pos[0] = j1;
        for(j2 = 0; j2 < b; j2++) {
            pos[1] = j2;
            ib = pos[j]+len[j]*pos[i];
            out[ib] = in[ia++] * factor;
        }
    }
}

/* Rearrange the 4d input array, multiplying values by the amplitude factor.
 * [a,b,c,d] defines the length, along each dimension, of the input arrays.
 * [i,j,k,l] defines the target index order.  [0,1,2,3] is a direct copy. */
void tce_sort_4(double *in, double *out, int a, int b, int c, int d, int i, int j, int k, int l, double factor) {
    /* a simple extrapolation of TCE_SORT_2.  The original TCE has two
     * tce_sort_4*.F sources, it's not clear which one is used, and they are
     * both much more heavily optimized than this. */
    int pos[4],len[4],ia,ib,j1,j2,j3,j4;
    ia = 0;
    len[0] = a;
    len[1] = b;
    len[2] = c;
    len[3] = d;
    for(j1 = 0; j1 < a; j1++) {
        pos[0] = j1;
        for(j2 = 0; j2 < b; j2++) {
            pos[1] = j2;
            for(j3 = 0; j3 < c; j3++) {
                pos[2] = j3;
                for(j4 = 0; j4 < d; j4++) {
                    pos[3] = j4;
                    ib = len[j]*len[k]*len[l]*pos[i]
                       +        len[k]*len[l]*pos[j]
                       +               len[l]*pos[k]
                       +                      pos[l];
                    out[ib] = in[ia++] * factor;
                }
            }
        }
    }
}
void tce_sortacc_4(double *in, double *out, int a, int b, int c, int d, int i, int j, int k, int l, double factor) {
    /* Same as tce_sort_4, above, but uses += instead of =. */
    int pos[4],len[4],ia,ib,j1,j2,j3,j4;
    ia = 0;
    len[0] = a;
    len[1] = b;
    len[2] = c;
    len[3] = d;
    for(j1 = 0; j1 < a; j1++) {
        pos[0] = j1;
        for(j2 = 0; j2 < b; j2++) {
            pos[1] = j2;
            for(j3 = 0; j3 < c; j3++) {
                pos[2] = j3;
                for(j4 = 0; j4 < d; j4++) {
                    pos[3] = j4;
                    ib = len[j]*len[k]*len[l]*pos[i]
                       +        len[k]*len[l]*pos[j]
                       +               len[l]*pos[k]
                       +                      pos[l];
                    out[ib] += in[ia++] * factor;
                }
            }
        }
    }
}

#define index_pair(i,j) ((i*(i+1))/2+j)
#define index_point(i,j,n) ((n*(n+1))/2-((n-i)*(n-i+1))/2-(n-j))


static int hash_comparator(const void *a_, const void *b_) {
    int *a = (int*)a_, *b = (int*)b_;
    return *a - *b;
}
/* Despite being called a "hash", it's a simple key-value lookup table.
 * hash points at an array of 2N+1 integers, with the following layout:
 * [ N | keys (N of these) | values (N of these) ] */
int tce_hash(int *hash, int key) {
    /* essentially the same as the one in tce_hash.F */
    int N = hash[0];

    int *elem = bsearch(&key, &hash[1], N, sizeof(key), hash_comparator);
    if(!elem) {
        int i;
        for(i = 0; i < NUM_VECTORS; i++)
            if(hash == vectors[i])
                break;
        char *name;
        if(i < NUM_VECTORS)
            name = vector_names[i];
        else {
            name = "unknown";
            for(i = 0; i < NUM_VECTORS; i++)
                debug("vectors[%d] (%s) = %p", i, vector_names[i], vectors[i]);
        }
        die("key %d not found in %s hash (%p)", key, name, hash);
    }
    int o = elem - &hash[1];
    return hash[N+o+1];
}
struct tce_hash_v2_lookup {
    int i, j, k, l, pos;
    long offset;
} *tce_hash_v2_lookup;
int tce_hash_v2_count;
void tce_hash_v2_prepare(const int *hash, int M) {
    /* Build a lookup table such that tce_hash_v2() never has to iterate more
     * than M times.  (Said another way, it never has to move more than M
     * entries from the starting point. This lookup table replaces the
     * k_v2_alpha_offset array provided by nwchem. */
    int N = noa+nva;
    int entries = 0, skip = 0;
    long offset = 0;
    int i, j, k, l, pos, pos_u = N*N*N*N;
    i = j = k = l = pos = 0;
    printf("preparing tce_hash_v2 lookup table...");
    while(pos < pos_u) {
        if(k_spin_alpha[i]+k_spin_alpha[j] == k_spin_alpha[k]+k_spin_alpha[l]) {
            if((k_sym_alpha[i] ^ k_sym_alpha[j] ^ k_sym_alpha[k] ^ k_sym_alpha[l]) == irrep_v) {
                if(index_pair(j,i) >= index_pair(l,k)) {
                    entries++;
                }
            }
        }
        l++;
        pos++;
        if(l == N) {
            k++;
            if(k == N) {
                k = 0;
                j++;
                if(j == N) {
                    i++;
                    j = i;
                    pos += j * N * N;
                }
            }
            l = k;
            pos += l;
        }
    }
    if(entries % M)
        entries += entries % M;
    entries /= M;
    entries++;
    printf("%d entries allocated...", entries);
    tce_hash_v2_lookup = malloc(sizeof(struct tce_hash_v2_lookup)*entries);
    memset(tce_hash_v2_lookup, 0, sizeof(struct tce_hash_v2_lookup)*entries);
    struct tce_hash_v2_lookup *this = tce_hash_v2_lookup;
    i = j = k = l = pos = 0;
    while(pos < pos_u) {
        if(k_spin_alpha[i]+k_spin_alpha[j] == k_spin_alpha[k]+k_spin_alpha[l]) {
            if((k_sym_alpha[i] ^ k_sym_alpha[j] ^ k_sym_alpha[k] ^ k_sym_alpha[l]) == irrep_v) {
                if(index_pair(j,i) >= index_pair(l,k)) {
                    if(!(skip++ % M)) {
                        this->i = i;
                        this->j = j;
                        this->k = k;
                        this->l = l;
                        this->pos = pos;
                        this->offset = offset;
                        this++;
                    }
                    offset += k_range_alpha[i]*
                              k_range_alpha[j]*
                              k_range_alpha[k]*
                              k_range_alpha[l];
                }
            }
        }
        l++;
        pos++;
        if(l == N) {
            k++;
            if(k == N) {
                k = 0;
                j++;
                if(j == N) {
                    i++;
                    j = i;
                    pos += j * N * N;
                }
            }
            l = k;
            pos += l;
        }
    }
    this->i = i;
    this->j = j;
    this->k = k;
    this->l = l;
    this->pos = pos;
    this->offset = offset;
    this++;
    tce_hash_v2_count = this - tce_hash_v2_lookup;
    printf("%d used.\n", tce_hash_v2_count);
}
long tce_hash_v2(const int *hash, int key) {
    /* Equivalent to the subroutine in tce_hash.F.  Adapted to use C style
     * zero-based indexing, and rewritten loop iterator logic. */
    int N = noa+nva;
    long offset;
    int middle, min, max,
        i, j, k, l,
        i_start, j_start, k_start, l_start,
        pos, pos_l, pos_u;
    /* The purpose of this function is as follows.  Given an [i,j,k,l]
     * permutation index (key), generated by:
     * key = i*(noa+nva)^3 + j*(noa+nva)^2 + k*(noa+nva) + l
     * And a method of calculating the size for each position in the [i,j,k,l]
     * space:
     * size = k_range_alpha[i]*k_range_alpha[j]*k_range_alpha[k]*k_range_alpha[l]
     * And given some symmetry constraints (funky if-statements) to determine
     * whether the ijkl position is actually stored in the v2 array, find
     * the offset in the v2 array for the data block associated with the key.
     * (Or die with an error message if the symmetry constraints failed.)
     *
     * The tce_hash_v2_lookup[] table provides some starting points for this
     * search.  The code starts from the closest predecessor row, and loops
     * until it gets to the right index, adding offsets for valid blocks it
     * encounters along the way.
     */
    min = middle = 0;
    max = tce_hash_v2_count - 1;
    while(min < max) {
        middle = (max - min) / 2 + min + 1;
        if(tce_hash_v2_lookup[middle].pos <= key)
            min = middle;
        else
            max = middle - 1;
    }
    middle = min;
    if(middle == tce_hash_v2_count-1) {
        if(tce_hash_v2_lookup[middle+1].pos == key)
            return tce_hash_v2_lookup[middle+1].offset;
        die("tce_hash_v2: key %d not found", key);
    }
    die_if(tce_hash_v2_lookup[middle].pos > key || tce_hash_v2_lookup[middle+1].pos <= key);
    // middle is fixed
    i_start = tce_hash_v2_lookup[middle].i;
    j_start = tce_hash_v2_lookup[middle].j;
    k_start = tce_hash_v2_lookup[middle].k;
    l_start = tce_hash_v2_lookup[middle].l;

    offset      = tce_hash_v2_lookup[middle].offset;
    pos = pos_l = tce_hash_v2_lookup[middle].pos;
    pos_u       = tce_hash_v2_lookup[middle+1].pos;
    i = i_start;
    j = j_start;
    k = k_start;
    l = l_start;
    die_if(l + N*(k + N*(j + N*i)) != pos_l);

    while(pos < pos_u) {
        if(k_spin_alpha[i]+k_spin_alpha[j] == k_spin_alpha[k]+k_spin_alpha[l]) {
            if((k_sym_alpha[i] ^ k_sym_alpha[j] ^ k_sym_alpha[k] ^ k_sym_alpha[l]) == irrep_v) {
                if(index_pair(j,i) >= index_pair(l,k)) {
                    if(pos == key) break;
                    long size = k_range_alpha[i]*
                                k_range_alpha[j]*
                                k_range_alpha[k]*
                                k_range_alpha[l];

                    offset += size;
                }
            }
        }

        /* advance ijkl and pos1, taking advantage of j>=i and l>=k to skip some rounds */
        /* A j>=l skip is also possible, but is not currently implemented */
        l++;
        pos++;
        if(l == N) {
            k++;
            if(k == N) {
                k = 0;
                j++;
                if(j == N) {
                    i++;
                    if(i == N)
                        die("tce_hash_v2: failed to find value for key %d (end of permutation range)", key);
                    j = i;
                    pos += j * N * N;
                }
            }
            l = k;
            pos += l;
        }
    }
    if(pos >= pos_u)
        die("tce_hash_v2: failed to find value for key %d (end of bucket range)", key);
    return offset;
}

void tce_get_block_ind_i(double *in, double *out, int dim, int g2b, int g1b, int g4b, int g3b);
void tce_get_hash_block(double *in, double *out, int dim, int *hash, int key) {
    int offset;
    offset = tce_hash(hash, key);
    memcpy(out, &in[offset], dim*sizeof(*out));
    return;
}

void tce_add_hash_block(double *out, double *in, int dim, int *hash, int key) {
    int i, offset = tce_hash(hash, key);
    for(i = 0; i < dim; i++)
        out[offset+i] += in[i];
}

void write_tensor(char *filename, double *data, size_t len) {
    size_t record_size = 2*1024*1024/8;
    double d;
    FILE *f = fopen(filename, "w");
    fwrite(data, sizeof(*data), len, f);
    while(len % record_size) {
        d = 0;
        fwrite(&d, sizeof(d), 1, f);
        len++;
    }
    fclose(f);
}

void tce_get_block_ind_i(double *in, double *out, int dim, int w2b, int w1b, int w4b, int w3b) {
    /* Straight translation of the subroutine in get_block_ind.F, minus the unused "indexc" argument. */
    int i,j,k,l,ispin,g1b,g2b,g3b,g4b,size1,size2,size3,size4,offset_alpha,key_alpha;
    bool l31s,l42s,lp31p42,l32s,l41s,lp32p41;
    int ig1b,ig2b,ig3b,ig4b,irow,icol;
    bool uaadaa,ubbdbb,uabdab,ubadba,ubadab,uabdba;
    int first_h,second_h,i1,j1,k1,l1,inx1,inx2,inx3,inx4;
    double *tmp;

    memset(out,0,dim*sizeof(*out));

    inx1 = w1b;
    inx2 = w2b;
    inx3 = w3b;
    inx4 = w4b;
    i1 = k_b2am[w1b];
    j1 = k_b2am[w3b];
    k1 = k_b2am[w2b];
    l1 = k_b2am[w4b];
    if(i1 >= j1) {
        i = i1;
        j = j1;
    } else {
        i = j1;
        j = i1;
    }
    if(k1 >= l1) {
        k = k1;
        l = l1;
    } else {
        k = l1;
        l = k1;
    }
    irow = index_pair(i,j);
    icol = index_pair(k,l);
    if(irow >= icol)
        first_h = k-1 + (noa+nva)*(l-1 + (noa+nva)*(i-1 + (noa+nva)*(j-1)));
    else
        first_h = i-1 + (noa+nva)*(j-1 + (noa+nva)*(k-1 + (noa+nva)*(l-1)));

    i1 = k_b2am[w2b];
    j1 = k_b2am[w3b];
    k1 = k_b2am[w1b];
    l1 = k_b2am[w4b];
    if(i1 >= j1) {
        i = i1;
        j = j1;
    } else {
        i = j1;
        j = i1;
    }
    if(k1 >= l1) {
        k = k1;
        l = l1;
    } else {
        k = l1;
        l = k1;
    }
    irow = index_pair(i,j);
    icol = index_pair(k,l);
    if(irow >= icol)
        second_h = k-1 + (noa+nva)*(l-1 + (noa+nva)*(i-1 + (noa+nva)*(j-1)));
    else
        second_h = i-1 + (noa+nva)*(j-1 + (noa+nva)*(k-1 + (noa+nva)*(l-1)));

    irow = 0;
    icol = 0;
    g1b  = 0;
    g2b  = 0;
    g3b  = 0;
    g4b  = 0;

    // v^{g3b<g4b}_{g1b<g2b} => ( g3b g1b | g4b g2b ) - ( g3b g2b | g4b g1b )
    uaadaa = FALSE;
    ubbdbb = FALSE;
    uabdab = FALSE;
    ubadba = FALSE;
    ubadab = FALSE;
    uabdba = FALSE;
    g3b = inx3;
    g4b = inx4;
    g1b = inx1;
    g2b = inx2;

    ispin = k_spin[g3b] + k_spin[g4b] + k_spin[g1b] + k_spin[g2b];
    if(ispin == 4) uaadaa = TRUE;
    if(ispin == 8) ubbdbb = TRUE;
    if(k_spin[g3b] == 1 && k_spin[g4b] == 2 && k_spin[g1b] == 1 && k_spin[g2b] == 2)
        uabdab = TRUE;
    if(k_spin[g3b] == 2 && k_spin[g4b] == 1 && k_spin[g1b] == 2 && k_spin[g2b] == 1)
        ubadba = TRUE;
    if(k_spin[g3b] == 2 && k_spin[g4b] == 1 && k_spin[g1b] == 1 && k_spin[g2b] == 2)
        ubadab = TRUE;
    if(k_spin[g3b] == 1 && k_spin[g4b] == 2 && k_spin[g1b] == 2 && k_spin[g2b] == 1)
        uabdba = TRUE;
    if (uaadaa || ubbdbb || uabdab || ubadba) {
        // first half
        key_alpha = first_h;
        // defining the order
        ig1b = k_b2am[g1b];
        ig2b = k_b2am[g2b];
        ig3b = k_b2am[g3b];
        ig4b = k_b2am[g4b];
        if(ig3b >= ig1b) {
          l31s = FALSE;
          irow = index_pair(ig3b,ig1b);
        } else {
          l31s = TRUE;
          irow = index_pair(ig1b,ig3b);
        }
        if(ig4b >= ig2b) {
          l42s = FALSE;
          icol = index_pair(ig4b,ig2b);
        } else {
          l42s = TRUE;
          icol = index_pair(ig2b,ig4b);
        }
        if(irow >= icol)
           lp31p42 = FALSE;
        else
          lp31p42 = TRUE;

        offset_alpha = tce_hash_v2(k_v2_alpha_offset, key_alpha);
        tmp = tce_double_malloc(dim);
        /* call ga_get(d_v2orb,offset_alpha+1,offset_alpha+size,1,1,dbl_mb(k_a),1) */
        memcpy(tmp, in+offset_alpha, dim*sizeof(*out));


        size1 = k_range[g1b];
        size2 = k_range[g2b];
        size3 = k_range[g3b];
        size4 = k_range[g4b];

        if(!lp31p42 && !l31s && !l42s)
            // --- ( g3 g1 | g4 g2 )
            tce_sortacc_4(tmp,out,size2,size1,size4,size3,3,1,2,0,1.0);
        else if(!lp31p42 && !l31s && l42s)
            // --- ( g3 g1 | g2 g4 )
            tce_sortacc_4(tmp,out,size4,size2,size1,size3,3,0,2,1,1.0);
        else if(!lp31p42 && l31s && !l42s)
            // --- ( g1 g3 | g4 g2 )
            tce_sortacc_4(tmp,out,size2,size4,size3,size1,2,1,3,0,1.0);
        else if(!lp31p42 && l31s && l42s)
            // --- ( g1 g3 | g2 g4 )
            tce_sortacc_4(tmp,out,size4,size2,size3,size1,2,0,3,1,1.0);
        else if(lp31p42 && !l31s && !l42s)
            // --- ( g4 g2 | g3 g1 )
            tce_sortacc_4(tmp,out,size1,size3,size2,size4,1,3,0,2,1.0);
        else if(lp31p42 && l31s && !l42s)
            // --- ( g4 g2 | g1 g3 )
            tce_sortacc_4(tmp,out,size3,size1,size2,size4,0,3,1,2,1.0);
        else if(lp31p42 && !l31s && l42s)
            // --- ( g2 g4 | g3 g1 )
            tce_sortacc_4(tmp,out,size1,size3,size4,size2,1,2,0,3,1.0);
        else if(lp31p42 && l31s && l42s)
            // --- ( g2 g4 | g1 g3 )
            tce_sortacc_4(tmp,out,size3,size1,size4,size2,0,2,1,3,1.0);

        free(tmp);
    } // !spin cases


    if(uaadaa || ubbdbb || uabdba || ubadab) {
        // second half
        key_alpha = second_h;
        // defining the order
        ig2b = k_b2am[g2b];
        ig1b = k_b2am[g1b];
        ig3b = k_b2am[g3b];
        ig4b = k_b2am[g4b];
        if(ig3b >= ig2b) {
          l32s = FALSE;
          irow = index_pair(ig3b,ig2b);
        } else {
          l32s = TRUE;
          irow = index_pair(ig2b,ig3b);
        }
        if(ig4b >= ig1b) {
          l41s = FALSE;
          icol = index_pair(ig4b,ig1b);
        } else {
          l41s = TRUE;
          icol = index_pair(ig1b,ig4b);
        }
        if(irow >= icol)
          lp32p41 = FALSE;
        else
          lp32p41 = TRUE;

        offset_alpha = tce_hash_v2(k_v2_alpha_offset, key_alpha);
        tmp = tce_double_malloc(dim);
        /* call ga_get(d_v2orb,offset_alpha+1,offset_alpha+size,1,1,dbl_mb(k_a),1) */
        memcpy(tmp, in+offset_alpha, dim*sizeof(*out));

        size3 = k_range[g3b];
        size1 = k_range[g1b];
        size4 = k_range[g4b];
        size2 = k_range[g2b];

        if(!lp32p41 && !l32s && !l41s)
            // --- ( g3 g2 | g4 g1 )
            tce_sortacc_4(tmp,out,size1,size4,size2,size3,3,1,0,2,-1.0);
        else if(!lp32p41 && !l32s && l41s)
            // --- ( g3 g2 | g1 g4 )
            tce_sortacc_4(tmp,out,size2,size1,size4,size3,3,0,1,2,-1.0);
        else if(!lp32p41 && l32s && !l41s)
            // --- ( g2 g3 | g4 g1 )
            tce_sortacc_4(tmp,out,size1,size4,size3,size2,2,1,0,3,-1.0);
        else if(!lp32p41 && l32s && l41s)
            // --- ( g2 g3 | g1 g4 )
            tce_sortacc_4(tmp,out,size1,size4,size3,size2,2,0,1,3,-1.0);
        else if(lp32p41 && !l32s && !l41s)
            // --- ( g4 g1 | g3 g2 )
            tce_sortacc_4(tmp,out,size2,size3,size1,size4,1,3,2,0,-1.0);
        else if(lp32p41 && l32s && !l41s)
            // --- ( g4 g1 | g2 g3 )
            tce_sortacc_4(tmp,out,size3,size2,size1,size4,0,3,2,1,-1.0);
        else if(lp32p41 && !l32s && l41s)
            // --- ( g1 g4 | g3 g2 )
            tce_sortacc_4(tmp,out,size2,size1,size4,size3,1,2,3,0,-1.0);
        else if(lp32p41 && l32s && l41s)
            // --- ( g1 g4 | g2 g3 )
            tce_sortacc_4(tmp,out,size3,size2,size1,size4,0,2,3,1,-1.0);

        free(tmp);
    } // !spin cases

}

CODELET_IMPL_BEGIN_EXPORTED_NOCANCEL(free)
//    debug("free %p", THIS);
    free(THIS);
    swarm_dispatch(NEXT, NEXT_THIS, NULL, NULL, NULL);
CODELET_IMPL_END;

CODELET_IMPL_BEGIN_EXPORTED_NOCANCEL(sum)
    argument_list_t *list = INPUT;
    int i, j;
    double *out = tce_double_malloc(list->len);
    for(i = 0; i < list->len; i++) {
        for(j = 0; j < list->count; j++) {
            out[i] += ((double*)list->args[j].buffer)[i];
        }
    }
//    debug("sum done %p", list);
    swarm_dispatch(list->done.NEXT, list->done.NEXT_THIS, out, &CODELET(free), out);
    swarm_dispatch(&CODELET(free_arg_list), list, NULL, NEXT, NEXT_THIS);
CODELET_IMPL_END;

CODELET_IMPL_BEGIN_EXPORTED_NOCANCEL(satisfy)
    double *buffer = INPUT;
    argument_chunk_t *arg = THIS;
    argument_list_t *list = arg->head;
//    debug("satisfy THIS=%p INPUT=%p list=%p dep=%p", THIS, INPUT, list, &list->dep);
    arg->free.NEXT      = NEXT;
    arg->free.NEXT_THIS = NEXT_THIS;
    arg->buffer = buffer;
    swarm_Dep_satisfyOnce(&list->dep);
CODELET_IMPL_END;

CODELET_IMPL_BEGIN_EXPORTED_NOCANCEL(free_arg_list)
    argument_list_t *list = THIS;
    int i;
//    debug("free_arg_list(%p)", list);
    for(i = 0; i < list->count; i++) {
        argument_chunk_t *arg = &list->args[i];
        swarm_dispatch(arg->free.NEXT, arg->free.NEXT_THIS, NULL, NULL, NULL);
    }
    swarm_deinit(swarm_Dep_to_Any(&list->dep));
    swarm_dispatch(&CODELET(free), list, NULL, NEXT, NEXT_THIS);
CODELET_IMPL_END;
